/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import java.net.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

class Sound
{
    public Sound()
    {
    }
    public void playCannon() {
        try 
        {
            URL url = this.getClass().getResource("/game/cannon.wav");
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    public void playHit()
    {
        try 
        {
            URL url = this.getClass().getResource("/game/hit.wav");
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    public void playBG()
    {
        try 
        {
            URL url = this.getClass().getResource("/game/bg.wav");
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    public void playPirate1()
    {
        try 
        {
            URL url = this.getClass().getResource("/game/pirate1.wav");
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    public void playPirate2()
    {
        try 
        {
            URL url = this.getClass().getResource("/game/pirate2.wav");
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    public void playPirate3()
    {
        try 
        {
            URL url = this.getClass().getResource("/game/pirate1.wav");
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    public void playPirate4()
    {
        try 
        {
            URL url = this.getClass().getResource("/game/pirate2.wav");
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } 
        catch (Exception e) 
        {
            System.out.println(e);
        }
    }
    
}