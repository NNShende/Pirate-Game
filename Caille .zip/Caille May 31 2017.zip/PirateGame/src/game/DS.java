package game;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;
import javax.swing.Timer;

public class DS extends JPanel implements ActionListener, KeyListener {

    public static int screenWidth;
    public static int screenHeight;
    public static int gameWidth;
    public static int gameHeight;
    public static int tileSize;
    public static double scale;
    public static int gap;

    private Timer timer;
    private final int FPS = 60;
    private int delay = 1000 / FPS;

    private boolean right = false;
    private boolean left = false;
    private boolean up = false;
    private boolean down = false;
    private boolean space = false;

    public int menuSelect = 1;
    public int optionSelect = 1;
    public boolean onLeft = true;
    public String[] menuPlay = {"Play!", "game 1", "game 2", "game 3"};
    public String[] menuSettings = {"Settings!", "Volume", "soemthing idk"};
    public String[] menuCredits = {"Credits!"};
    public String[] menuExit = {"Close game?", "get me outta here", "nah lets keep going"};
    public String[][] menuSelections = {menuPlay, menuSettings, menuCredits, menuExit};

    public boolean gamePlay = false;

    private Map map;
    private Ship playerShip;
    private ShipStats ss;
    private Ship enemyShip;

    public static void getBestSize() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        screenWidth = screenSize.width;
        screenHeight = screenSize.height;

        int sizeFactorX = screenWidth / 19;
        int sizeFactorY = screenHeight / 10;

        if (sizeFactorX > sizeFactorY) {
            tileSize = sizeFactorY;
        } else {
            tileSize = sizeFactorX;
        }
        gameWidth = tileSize * 14;
        gameHeight = tileSize * 10;
        gap = (screenHeight - gameHeight) / 2;
        scale = tileSize / 128.0;
    }

    public DS() {
        init();
        addKeyListener(this);
        setFocusable(true);
        timer = new Timer(delay, this);
        timer.start();
    }

    public void init() {
        getBestSize();
        map = new Map();
        playerShip = new PlayerShip(0, gameWidth / 5, gameHeight / 3, 10, 0, 100);
        map.setMapSecX(2);
        map.setMapSecY(2);

        ss = new ShipStats(0.02, 0, 2);
    }

    public void paintComponent(Graphics g_) {
        Graphics2D g = (Graphics2D) g_;

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        if (!gamePlay) {
            g.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
            map.drawMap(g);
            g.fillRect(gameWidth / 8, DS.gap + (gameHeight / 13), gameWidth * 3 / 4, gameHeight * 2 / 13);
            g.fillRect(gameWidth / 8, DS.gap + (4 * gameHeight / 13), gameWidth * 3 / 4, gameHeight * 2 / 13);
            g.fillRect(gameWidth / 8, DS.gap + (7 * gameHeight / 13), gameWidth * 3 / 4, gameHeight * 2 / 13);
            g.fillRect(gameWidth / 8, DS.gap + (10 * gameHeight / 13), gameWidth * 3 / 4, gameHeight * 2 / 13);
            g.setColor(Color.WHITE);
            g.drawString("start", gameWidth / 2, DS.gap + (2 * gameHeight / 13));
            g.drawString("settings", gameWidth / 2, DS.gap + (5 * gameHeight / 13));
            g.drawString("el credito", gameWidth / 2, DS.gap + (8 * gameHeight / 13));
            g.drawString("SEE YA", gameWidth / 2, DS.gap + (11 * gameHeight / 13));
            g.setColor(Color.RED);
            g.setStroke(new BasicStroke(10));
            if (menuSelect == 5) {
                menuSelect = 1;
            } else if (menuSelect == 0) {
                menuSelect = 4;
            }
            if (menuSelections[menuSelect - 1].length != 1) {
                if (optionSelect == menuSelections[menuSelect - 1].length) {
                    optionSelect = 1;
                } else if (optionSelect == 0) {
                    optionSelect = menuSelections[menuSelect - 1].length - 1;
                }

            }

            if (!onLeft && menuSelections[menuSelect - 1].length != 1) {
                g.drawRect(gameWidth + ((screenWidth - gameWidth) / 30), (2 * DS.gap) + (gameHeight * (optionSelect + 1) / 10), ((screenWidth - gameWidth) * 9 / 10), (2 / 3 * DS.gap) + (gameHeight / 10));
            }

            g.drawRect(gameWidth / 8, DS.gap + ((-2 + (3 * menuSelect)) * gameHeight / 13), gameWidth * 3 / 4, gameHeight * 2 / 13);

            g.drawString(menuSelections[menuSelect - 1][0], gameWidth + ((screenWidth - gameWidth) / 10), DS.gap + (gameHeight / 10));

            for (int i = 0; i < menuSelections[menuSelect - 1].length - 1; i++) {
                g.drawString(menuSelections[menuSelect - 1][i + 1], gameWidth + ((screenWidth - gameWidth) / 10), DS.gap + (gameHeight / 10) * (i + 3));
            }

        }
        if (gamePlay) {

            map.drawMap(g);
            double xRan = (Math.random() * gameWidth);
            double yRan = (Math.random() * gameHeight);
            double spawnChance = 0.5;
            if (map.getMapSecY() < map.getMapSecYSize() - 1 && playerShip.getY() > gameHeight) {
                map.setMapSecY(map.getMapSecY() + 1);
                playerShip.setY(gap);
                playerShip.clearBalls();
                enemyShip = null;
                if (Math.random() < spawnChance) {
                    while (map.getTile((int) Math.round(xRan) / tileSize, (int) Math.round(yRan) / tileSize) != 0) {
                        xRan = (Math.random() * gameWidth);
                        yRan = (Math.random() * gameHeight);
                    }
                    enemyShip = new EnemyShip(xRan, yRan, (int) (Math.random() * 5) + 4, Math.random() * 360, 75);

                }
            }
            if (map.getMapSecY() > 0 && playerShip.getY() < 0) {
                map.setMapSecY(map.getMapSecY() - 1);
                playerShip.setY(gameHeight + gap);
                playerShip.clearBalls();
                enemyShip = null;
                if (Math.random() < spawnChance) {
                    while (map.getTile((int) Math.round(xRan) / tileSize, (int) Math.round(yRan) / tileSize) != 0) {
                        xRan = (Math.random() * gameWidth);
                        yRan = (Math.random() * gameHeight);
                    }
                    enemyShip = new EnemyShip(xRan, yRan, (int) (Math.random() * 5) + 4, Math.random() * 360, 75);

                }
            }
            if (map.getMapSecX() < map.getMapSecXSize() - 1 && playerShip.getX() > gameWidth) {
                map.setMapSecX(map.getMapSecX() + 1);
                playerShip.setX(0);
                playerShip.clearBalls();
                enemyShip = null;
                if (Math.random() < spawnChance) {
                    while (map.getTile((int) Math.round(xRan) / tileSize, (int) Math.round(yRan) / tileSize) != 0) {
                        xRan = (Math.random() * gameWidth);
                        yRan = (Math.random() * gameHeight);
                    }
                    enemyShip = new EnemyShip(xRan, yRan, (int) (Math.random() * 5) + 4, Math.random() * 360, 75);

                }
            }
            if (map.getMapSecX() > 0 && playerShip.getX() < 0) {
                map.setMapSecX(map.getMapSecX() - 1);
                playerShip.setX(gameWidth);
                playerShip.clearBalls();
                enemyShip = null;
                if (Math.random() < spawnChance) {
                    while (map.getTile((int) Math.round(xRan) / tileSize, (int) Math.round(yRan) / tileSize) != 0) {
                        xRan = (Math.random() * gameWidth);
                        yRan = (Math.random() * gameHeight);
                    }
                    enemyShip = new EnemyShip(xRan, yRan, (int) (Math.random() * 5) + 4, Math.random() * 360, 75);

                }
            }
            if (enemyShip != null) {
                ((EnemyShip) enemyShip).drawEnemyShip(g);
            }

            try {
                if (up && map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) != 0 && playerShip.getBackDocked() == false) {
                    playerShip.setFrontDocked(true);
                } else if (map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) == 0) {
                    playerShip.setFrontDocked(false);
                }
                if (down && map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) != 0 && playerShip.getFrontDocked() == false) {
                    playerShip.setBackDocked(true);
                } else if (map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) == 0) {
                    playerShip.setBackDocked(false);
                }
            } catch (Exception e) {
            }

            try {
                if (!enemyShip.getFrontDocked() && map.getTile((int) Math.round(enemyShip.getX()) / tileSize, (int) Math.round(enemyShip.getY()) / tileSize) != 0) {
                    enemyShip.setFrontDocked(true);
                } else if (enemyShip.getFrontDocked() && map.getTile((int) Math.round(enemyShip.getX()) / tileSize, (int) Math.round(enemyShip.getY()) / tileSize) != 0) {
                    enemyShip.setFrontDocked(false);
                }

            } catch (Exception e) {
            }

            enemyShip = playerShip.updateHealth(enemyShip);
            ((PlayerShip) playerShip).drawPlayerShip(g);
            ss.setGold(playerShip.getHealth());
            ss.update(g);

            map.drawSidebar(g);
            g.setPaint(Color.black);
            g.fillRect(0, 0, screenWidth, gap);
            g.fillRect(0, screenHeight - gap, screenWidth, gap);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
        if (!playerShip.getFrontDocked() && !playerShip.getBackDocked()) {
            if (right && (up || down)) {
                playerShip.incR(1);
            }
            if (left && (up || down)) {
                playerShip.decR(1);
            }
        }
        if (up && !playerShip.getFrontDocked()) {
            playerShip.decX();
            playerShip.incY();
        }
        if (down && !playerShip.getBackDocked()) {
            playerShip.incX();
            playerShip.decY();
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (!gamePlay) {
            int key = e.getKeyCode();
            if (onLeft) {
                if (key == KeyEvent.VK_DOWN) {
                    menuSelect++;
                }
                if (key == KeyEvent.VK_UP) {
                    menuSelect--;
                }
                if (key == KeyEvent.VK_RIGHT) {
                    onLeft = false;
                }
            } else {
                if (key == KeyEvent.VK_LEFT) {
                    onLeft = true;
                    optionSelect = 1;
                } else if (key == KeyEvent.VK_UP) {
                    optionSelect--;
                } else if (key == KeyEvent.VK_DOWN) {
                    optionSelect++;
                } else if (key == KeyEvent.VK_SPACE) {
                    gamePlay = true;
                }
            }

        }
        if (gamePlay) {
            int key = e.getKeyCode();

            if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
                left = true;
            }

            if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
                right = true;
            }

            if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
                up = true;
            }

            if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                down = true;
            }

            if (key == KeyEvent.VK_SPACE) {
                space = true;
            }
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (gamePlay) {
            int key = e.getKeyCode();

            if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A) {
                left = false;
            }

            if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D) {
                right = false;
            }

            if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W) {
                up = false;
            }

            if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S) {
                down = false;
            }

            if (key == KeyEvent.VK_SPACE && space) {
                space = false;
                if (ss.getCurTime() >= 1) {
                    playerShip.fireCannons();
                    ss.setCurTime(0);
                }
            }
        }
    }

}
