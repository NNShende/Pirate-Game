package game;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

public class EnemyShip extends Ship {

    private static int gameWidth = DS.gameWidth;
    private static int gameHeight = DS.gameHeight;
    private double turnA;
    private double turnR;
    private Image enemyShip;
    private int cannonTimer;


    public EnemyShip(double xPos, double yPos, double mS, double a, int h) {
        super(xPos, yPos, mS, a, h);
        enemyShip = loadImage("/GameFiles/Ships/ship (2).png");
        cannonTimer = 0;
        frontDocked = false;
        turnA = Math.random();
        turnR = Math.random();
    }
    
    public void randomMove() {
        System.out.println(DS.gameWidth);
        System.out.println(DS.gameHeight);
        double fact = -xPos*(xPos-DS.gameWidth)/DS.gameWidth;
        fact *= -yPos*(yPos-DS.gameHeight)/DS.gameHeight;
        
        double maxFact = -(DS.gameWidth/2)*((DS.gameWidth/2)-DS.gameWidth)/DS.gameWidth * -(DS.gameHeight/2)*((DS.gameHeight/2)-DS.gameHeight)/DS.gameHeight;
        fact = maxFact/fact;
        fact += 0.5;
        fact *= 2.0/3.0;
        if (!frontDocked) {
            incY();
            decX();
        } else {
            incX();
            decY();
        }
        if (Math.random() < turnA) {
            if (Math.random() < turnR) {
                incR(fact);
            } else {
                decR(fact);
            }
        }
        
        
        
        cannonTimer++;
    }

    public void drawEnemyShip(Graphics2D g) {
        AffineTransform boatTrans = new AffineTransform();
        boatTrans.translate(xPos, yPos);
        boatTrans.rotate(Math.toRadians(angle));
        boatTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        boatTrans.translate(-enemyShip.getWidth(null) / 2, -enemyShip.getHeight(null) / 2);
        g.drawImage(enemyShip, boatTrans, null);
        randomMove();
        updateCannons(g);
        if (cannonTimer > 60) {
            fireCannons();
            cannonTimer = 0;
        }
    }

}
