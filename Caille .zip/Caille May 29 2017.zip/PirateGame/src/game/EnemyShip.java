/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 *
 * @author jamie
 */
public class EnemyShip extends Ship {
    private static int gameWidth = DS.gameWidth;
    private static int gameHeight = DS.gameHeight;
    private double turnA;
    private double turnR;
    public EnemyShip() {
        super((gameWidth / 4) + (Math.random() * (gameWidth / 2)), (gameHeight / 4) + (Math.random() * (gameHeight / 2))
                , 5, 0, 75);
        turnA = Math.random() * 100;
        turnR = Math.random();
    }
    public void randomMove()
    {
        incX();
        incY();
        if(Math.random() < turnA)
        {
            if(Math.random() < turnR)
            {
                incR();
            }
            else
            {
                decR();
            
            }
        }
    }
    
}
