package game;

import java.awt.Graphics2D;

public class Cannon {

    private double xPos;
    private double yPos;
    private double angle;
    private double speed;
    private Cannonball[] balls;
    private int count;

    public Cannon(double xPos, double yPos, double angle, double speed) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.angle = angle;
        this.speed = speed;
        balls = new Cannonball[10];
        count = 0;
    }

    public void drawBalls(Graphics2D g) {
        for (int i = 0; i < balls.length; i++) {
            if (balls[i] != null) {
                balls[i].move();
                balls[i].drawCannonball(g);
                
            }
        }
    }
    
    public void clearBalls(){
        for (int i= 0; i<balls.length; i++){
            balls[i] = null;
        }
    }

    public double getXPos() {
        return xPos;
    }

    public double getYPos() {
        return yPos;
    }

    public double getAngle() {
        return angle;
    }

    public void fireCannonball() {
        balls[count] = new Cannonball(xPos, yPos, angle + 90, speed);
        count++;
        if (count >= balls.length) {
            count = 0;
        }

    }

    public void setXPos(double x) {
        xPos = x;
    }

    public void setYPos(double y) {
        yPos = y;
    }

    public void setAngle(double a) {
        angle = a;
    }

}
