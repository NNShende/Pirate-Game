//Daniel Papadopoulos, Nikhil Shende, Jamie Caille
//June 6, 2017
//Cannonball class for handling those small metal spheres that cannons shoot. Includes
//drawing and moving functionalities
package game;
//imports the use of drawing loading and moving images
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

public class Cannonball {
//variables for x position, y position, angle, and speed
    private double xPos;
    private double yPos;
    private double angle;
    private double speed;
/**
 * constructor for cannonballs
 * @param xPos the x position
 * @param yPos the y position
 * @param angle the angle
 * @param speed the speed
 */
    public Cannonball(double xPos, double yPos, double angle, double speed) {
        //sets the x and y position
        this.xPos = xPos;
        this.yPos = yPos;
        //sets the angle
        this.angle = angle;
        //sets the speed
        this.speed = speed;
    }
/**
 * draws the cannonball
 * @param g the Graphics2D object to draw the cannonball with
 */
    public void drawCannonball(Graphics2D g) {
        //loads the image for cannonballs
        Image cannonball = loadImage("/GameFiles/Ship_parts/cannonBall.png");
        //creates an affine transform object for changing the cannonball drawing
        AffineTransform cannonBTrans = new AffineTransform();
        //moves the transform object to the cannonball
        cannonBTrans.translate(xPos, yPos);
        //scales the transform upwards based on the screen size
        cannonBTrans.scale(1.5 *DS.scale, 1.5 * DS.scale);
        //translates the transform to be centred on the cannonball's position
        cannonBTrans.translate(-cannonball.getWidth(null) / 2, -cannonball.getHeight(null) / 2);
        //draws the cannonball
        g.drawImage(cannonball, cannonBTrans, null);
        //moves the cannonball
        move();
    }
/**
 * moves the cannonball based on its speed and angle
 */
    public void move() {
        //decreases the x position based on the speed and sin of the angle
        xPos -= speed * Math.sin(Math.toRadians(angle));
        //increases the y position based on the speed and sin of the angle
        yPos += speed * Math.cos(Math.toRadians(angle));

    }
/**
 * loads an image
 * @param src the source file of the image
 * @return the image
 */
    public Image loadImage(String src) {
        //creates a variable to store the image in
        Image im = null;
        try {
            //loads the image from the source file
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
            //if something goes wrong, do nothing
        } catch (Exception e) {

        }
        //returns the image
        return im;
    }
    /**
     * gets the x position of the cannonball
     * @return the x position
     */
    public double getXPos(){
        //returns the x position
        return xPos;
    }
/**
 * gets the y position of the cannonball
 * @return the y position
 */
    public double getYPos() {
        //returns the y position
        return yPos;
    }
    
    

}
