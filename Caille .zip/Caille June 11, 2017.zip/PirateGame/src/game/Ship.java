//Daniel Papadopoulos, Nikhil Shende, Jamie Caille
//June 6, 2016
//Abstract class for ships. Provides functionality for all the actions that a basic
//ship must do. Used for player ships and enemy ships classes
package game;
//imports the use of drawing functionality, loading drawing and scaling images
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

abstract public class Ship {
    //Sound for playing noise
    protected static Sound so = new Sound();
    //ships have an x position, y position, angle that they're pointing ad, movement speed
    //if the back or front of the ship is docked, health, cannons, and damage
    protected double xPos;
    protected double yPos;
    protected double angle;
    protected double moveSpeed;
    protected boolean frontDocked;
    protected boolean backDocked;
    protected int health;
    protected Cannon[] cans;
    protected int damage;
/**
 * constructor for a ship
 * @param xPos x position of the ship
 * @param yPos y position of the ship
 * @param mS movement speed
 * @param a angle
 * @param h health
 */
    public Ship(double xPos, double yPos, double mS, double a, int h) {
        //sets the x position and y position
        this.xPos = xPos;
        this.yPos = yPos;
        //sets the angle
        angle = a;
        //sets the movement speed, based on size of screen
        moveSpeed = mS * DS.scale;
        //front and back of the ship are not docked
        frontDocked = false;
        backDocked = false;
        //creates an array for storing cannons
        cans = new Cannon[4];
        //gives the ship two cannons to start
        cans[0] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[1] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        //sets the health
        health = h;
        //sets the base damage
        damage = 5;
    }
    
/**
 * adds cannons to the ship
 */
    public void addCannons() {
        //fills up the cannon array, because cannons only go from 2 -> 4 in the game
        //when the user upgrades
        cans[0] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[1] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[2] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[3] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
    }
/**
 * shows the damage of the ship
 * @return the damage
 */
    public int getDamage() {
        //returns damage
        return damage;
    }
/**
 * sets the damage of the ship
 * @param damage the desired damage
 */
    public void setDamage(int damage) {
        //changes the damage of the ship's cannons to a desired amount
        this.damage = damage;
    }
/**
 * sets the movement speed of the ship and cannons
 * @param moveSpeed desired movement speed
 */
    public void setMoveSpeed(double moveSpeed) {
        //sets the movement speed of the ship
        this.moveSpeed = moveSpeed;
        //loops through the cannon array
        for (int i = 0; i < cans.length; i++) {
            //if a cannon is present at an index in the array
            if (cans[i] != null) {
                //changes the cannons movement speed
                cans[i].setSpeed(moveSpeed);
            }
        }
    }
    /**
     * gets the movement speed of the ship
     * @return the movement speed
     */
    public double getMoveSpeed() {
        //returns the movement speed
        return moveSpeed;
    }
    /**
     * gets the health of the ship
     * @return the health
     */
    public int getHealth() {
        //returns the health
        return health;
    }
    /**
     * sets the health of the ship 
     * @param val the desired health
     */
    public void setHealth(int val) {
        //sets the health to a desired valueu
        health = val;
    }
    /**
     * fires the cannons of the ship
     */
    public void fireCannons() {
        // loops through the cannon array
        for (int i = 0; i < cans.length; i++) {
            //if a cannon is present at a certain index
            if (cans[i] != null) {
                //fires a cannonball from the cannon
                cans[i].fireCannonball();
            }
        }
    }
    /**
     * updates the cannons drawing
     * @param g the Graphics2D object used to draw
     */
    public void updateCannons(Graphics2D g) {
        //if a first cannon is present
        if (cans[0] != null) {
            //draws a cannon at the first position of the ship
            cans[0].setXPos(xPos + 18 * Math.cos(Math.toRadians(angle)));
            cans[0].setYPos(yPos + 18 * Math.sin(Math.toRadians(angle)));
            //sets the angle of the cannon
            cans[0].setAngle(angle);
            //draws the cannon
            cans[0].drawCannon(g);
        }
        //if a second cannon is present
        if (cans[1] != null) {
            //draws a cannon at the second position of the ship
            cans[1].setXPos(xPos - 18 * Math.cos(Math.toRadians(angle)));
            cans[1].setYPos(yPos - 18 * Math.sin(Math.toRadians(angle)));
            //sets the angle of the cannon
            cans[1].setAngle(angle + 180);
            //draws the cannon
            cans[1].drawCannon(g);
        }
        //if a third cannon is present
        if (cans[2] != null) {
            //draws a cannon at the third position of the ship
            cans[2].setXPos(xPos + 18 * Math.cos(Math.toRadians(angle)) + 20 * Math.sin(Math.toRadians(angle)));
            cans[2].setYPos(yPos + 18 * Math.sin(Math.toRadians(angle)) - 20 * Math.cos(Math.toRadians(angle)));
            //sets the angle of the cannon
            cans[2].setAngle(angle);
            //draws the cannon
            cans[2].drawCannon(g);
        }
        //if a fourth cannon is present
        if (cans[3] != null) {
            //draws a cannon at the fourth position of the ship
            cans[3].setXPos(xPos - 18 * Math.cos(Math.toRadians(angle)) + 20 * Math.sin(Math.toRadians(angle)));
            cans[3].setYPos(yPos - 18 * Math.sin(Math.toRadians(angle)) - 20 * Math.cos(Math.toRadians(angle)));
            //sets the angle of the cannon
            cans[3].setAngle(angle + 180);
            //draws the cannon
            cans[3].drawCannon(g);
        }

    }
    /**
     * returns a cannon at a certain index
     * @param n the desired cannon index
     * @return the cannon
     */
    public Cannon getCannon(int n){
        //returns a cannon at a certain index
        return cans[n];
    }
    /**
     * deletes a cannonball from a certain cannon
     * @param n the cannon that shot the cannonball
     * @param pos the position of the cannonball in that cannon's array
     */
    public void deleteCannonball(int n, int pos){
        //deletes the cannonball
        cans[n].deleteCannonball(pos);
    }
    /**
     * returns the cannon array for the boat
     * @return the cannon array
     */
    public Cannon[] getCannonArray() {
        //returns the cannon array
        return cans;
    }
    /**
     * sets the cannon array to a new cannon array
     * @param c the new cannon array
     */
    public void setCannonArray(Cannon[] c) {
        //points the cannon array variable at the new cannon array
        cans = c;
    }
    /**
     * updates the health of the ship
     * @param s the ship that has possibly hit the current ship
     * @return the called ship but with updated cannons
     */
    public Ship updateHealth(Ship s) {
        //if the ship passed into the array is actually there
        if (s != null) {
            //gets the cannon array
            Cannon[] cannons = s.getCannonArray();
            //loops through the cannon array
            for (int i = 0; i < cannons.length; i++) {
                //loops through the cannonball array of each cannon
                for (int j = 0; j < Cannon.maxBalls; j++) {
                    //if there is a cannon at that index and a cannonball at that cannon's cannonball index
                    if (cannons[i] != null && cannons[i].getCannonball(j) != null) {
                        //if the cannonball of the passed ship is within the bounds of the ship that ran the function
                        if (Math.abs(cannons[i].getCannonball(j).getXPos() - xPos) < 50 && Math.abs(cannons[i].getCannonball(j).getYPos() - yPos) < 50) {
                            //plays the hit sound
                            so.playHit();
                            //subtracts the passed ship's damage from the ship's health
                            health -= s.getDamage();
                            //deletes the cannonball that hit
                            cannons[i].deleteCannonball(j);
                        }
                    }
                }
            }
            //reloads the cannon array to the new values
            s.setCannonArray(cannons);
        }
        //returns the ship
        return s;
    }
    /**
     * updates the health of the ship
     * @param f the fortress that may have hit the ship
     * @return the fortress but with updated cannons
     */
    public Fortress updateHealth(Fortress f) {
        //refer to above updateHealth, but checking and modifying a fortress
        //instead of a called ship
        if (f != null) {
            Cannon[] cannons = f.getCannonArray();
            for (int i = 0; i < cannons.length; i++) {
                for (int j = 0; j < Cannon.maxBalls; j++) {
                    if (cannons[i] != null && cannons[i].getCannonball(j) != null) {
                        if (Math.abs(cannons[i].getCannonball(j).getXPos() - xPos) < 50 && Math.abs(cannons[i].getCannonball(j).getYPos() - yPos) < 50) {
                            so.playHit();
                            health -= f.getDamage();
                            cannons[i].deleteCannonball(j);
                        }
                    }
                }
            }
            f.setCannonArray(cannons);
        }

        return f;
    }
    /**
     * clears all the cannonballs from a certain ship's cannons
     */
    public void clearBalls() {
        //loops through the cannon array
        for (int i = 0; i < cans.length; i++) {
            //if there is a cannon at an index
            if (cans[i] != null) {
                //delets all of the cannonballs from that cannon
                cans[i].clearBalls();
            }
        }
    }
    /**
     * loads a cannon
     * @param src the source file of the image
     * @return 
     */
    public Image loadImage(String src) {
        //creates a variable for the image
        Image im = null;
        //attempt to do this
        try {
            //loads the image at the source file
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
            //if that doesn't work, nothing happens
        } catch (Exception e) {

        }
        //returns the image
        return im;
    }
/**
 * increases the x position of a ship
 */
    public void incX() {
        //adds to the x position based on the movement speed and the angle of the ship
        xPos += moveSpeed * Math.sin(Math.toRadians(angle));
    }
/**
 * decreases the x position of a ship
 */
    public void decX() {
        //subtracts from the x position based on the movement speed and the angle of the ship
        xPos -= moveSpeed * Math.sin(Math.toRadians(angle));
    }
/**
 * increases the y position of a ship
 */
    public void incY() {
        //adds to the y position based on the movement speed and the angle of the ship
        yPos += moveSpeed * Math.cos(Math.toRadians(angle));
    }
/**
 * decreases the y position of a ship
 */
    public void decY() {
        //subtracts from the y position based on the movement speed and the angle of the ship
        yPos -= moveSpeed * Math.cos(Math.toRadians(angle));
    }
/**
 * rotates the ship in a positive direction
 * @param mult the multiplier by which to rotate (based on the scale)
 */
    public void incR(double mult) {
        //rotates the ship in a positive direction
        angle += moveSpeed * mult / 2;
    }
/**
 * rotates the ship in a negative direction
 * @param mult the multiplier by which to rotate
 */
    public void decR(double mult) {
        //rotates the ship in a negative direction
        angle -= moveSpeed * mult / 2;
    }
/**
 * gets the x position of the ship
 * @return the x position
 */
    public double getX() {
        //returns the x position
        return xPos;
    }
/**
 * gets the y position of the ship
 * @return the y position
 */
    public double getY() {
        //returns the y position without the gap at the top of the screen
        return yPos - DS.gap;
    }
/**
 * sets the x position of the ship
 * @param val the new x position
 */
    public void setX(double val) {
        //sets the x position
        xPos = val;
    }
/**
 * sets the y position of the ship
 * @param val the new y position
 */
    public void setY(double val) {
        //sets the y position
        yPos = val;
    }
/**
 * sets whether the front of the ship is docked
 * @param val the boolean if the ship is docked or not
 */
    public void setFrontDocked(boolean val) {
        //sets whether the front of the ship is docked
        frontDocked = val;
    }
/**
 * sets whether the front of the ship is docked
 * @param val the boolean if the ship is docked or not
 */
    public void setBackDocked(boolean val) {
        //sets whether the back of the ship is docked
        backDocked = val;
    }
/**
 * checks if the front of the ship is docked
 * @return the true/false if the front of the ship is docked
 */
    public boolean getFrontDocked() {
        //returns if the front of the ship is docked or not
        return frontDocked;
    }
/**
 * checks if the front of the ship is docked
 * @return the true/false if the front of the ship is docked
 */
    public boolean getBackDocked() {
        //returns if the front of the ship is docked or not
        return backDocked;
    }

}
