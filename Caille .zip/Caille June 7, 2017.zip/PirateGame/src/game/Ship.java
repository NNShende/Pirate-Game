package game;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

abstract public class Ship {

    protected static Sound so = new Sound();
    
    protected double xPos;
    protected double yPos;
    protected double angle;
    protected double moveSpeed;
    protected boolean frontDocked;
    protected boolean backDocked;
    protected int health;
    protected Cannon[] cans;
    protected int damage;

    public Ship(double xPos, double yPos, double mS, double a, int h) {//, Cannon[] c) {
        this.xPos = xPos;
        this.yPos = yPos;
        angle = a;
        moveSpeed = mS * DS.scale;
        frontDocked = false;
        backDocked = false;
        cans = new Cannon[4];
        cans[0] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[1] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        health = h;
        damage = 5;
    }

    public void addCannons() {
        cans[0] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[1] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[2] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
        cans[3] = new Cannon(xPos, yPos, angle, moveSpeed * 1.2);
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public void setMoveSpeed(double moveSpeed) {
        this.moveSpeed = moveSpeed;
        for (int i = 0; i<cans.length; i++){
            if (cans[i] != null){
                cans[i].setSpeed(moveSpeed);
            }
        }
    }

    public double getMoveSpeed() {
        return moveSpeed;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int val) {
        health = val;
    }

    public void fireCannons() {
        for (int i = 0; i < cans.length; i++) {
            if (cans[i] != null) {
                cans[i].fireCannonball();
            }
        }
    }

    public void updateCannons(Graphics2D g) {
        if (cans[0] != null) {
            cans[0].setXPos(xPos + 18 * Math.cos(Math.toRadians(angle)));
            cans[0].setYPos(yPos + 18 * Math.sin(Math.toRadians(angle)));
            cans[0].setAngle(angle);
            cans[0].drawCannon(g);
        }

        if (cans[1] != null) {
            cans[1].setXPos(xPos - 18 * Math.cos(Math.toRadians(angle)));
            cans[1].setYPos(yPos - 18 * Math.sin(Math.toRadians(angle)));
            cans[1].setAngle(angle + 180);
            cans[1].drawCannon(g);
        }

        if (cans[2] != null) {
            cans[2].setXPos(xPos + 18 * Math.cos(Math.toRadians(angle)) + 20 * Math.sin(Math.toRadians(angle)));
            cans[2].setYPos(yPos + 18 * Math.sin(Math.toRadians(angle)) - 20 * Math.cos(Math.toRadians(angle)));
            cans[2].setAngle(angle);
            cans[2].drawCannon(g);
        }

        if (cans[3] != null) {
            cans[3].setXPos(xPos - 18 * Math.cos(Math.toRadians(angle)) + 20 * Math.sin(Math.toRadians(angle)));
            cans[3].setYPos(yPos - 18 * Math.sin(Math.toRadians(angle)) - 20 * Math.cos(Math.toRadians(angle)));
            cans[3].setAngle(angle + 180);
            cans[3].drawCannon(g);
        }

    }

    public Cannon[] getCannonArray() {
        return cans;
    }

    public void setCannonArray(Cannon[] c) {
        cans = c;
    }

    public Ship updateHealth(Ship s) {
        if (s != null) {
            Cannon[] cannons = s.getCannonArray();
            for (int i = 0; i < cannons.length; i++) {
                for (int j = 0; j < Cannon.maxBalls; j++) {
                    if (cannons[i] != null && cannons[i].getCannonball(j) != null) {
                        if (Math.abs(cannons[i].getCannonball(j).getXPos() - xPos) < 50 && Math.abs(cannons[i].getCannonball(j).getYPos() - yPos) < 50) {
                            so.playHit();
                            health -= 5;
                            cannons[i].deleteCannonball(j);
                        }
                    }
                }
            }
            s.setCannonArray(cannons);
        }

        return s;
    }

    public void clearBalls() {
        for (int i = 0; i < cans.length; i++) {
            if (cans[i] != null) {
                cans[i].clearBalls();
            }
        }
    }

    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {

        }
        return im;
    }

    public void incX() {
        xPos += moveSpeed * Math.sin(Math.toRadians(angle));
    }

    public void decX() {
        xPos -= moveSpeed * Math.sin(Math.toRadians(angle));
    }

    public void incY() {
        yPos += moveSpeed * Math.cos(Math.toRadians(angle));
    }

    public void decY() {
        yPos -= moveSpeed * Math.cos(Math.toRadians(angle));
    }

    public void incR(double mult) {
        angle += moveSpeed * mult / 2;
    }

    public void decR(double mult) {
        angle -= moveSpeed * mult / 2;
    }

    public double getX() {
        return xPos;
    }

    public double getY() {
        return yPos - DS.gap;
    }

    public void setX(double val) {
        xPos = val;
    }

    public void setY(double val) {
        yPos = val;
    }

    public void setFrontDocked(boolean val) {
        frontDocked = val;
    }

    public void setBackDocked(boolean val) {
        backDocked = val;
    }

    public boolean getFrontDocked() {
        return frontDocked;
    }

    public boolean getBackDocked() {
        return backDocked;
    }

}
