package game;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Fortress {

    private int health;
    private int level;
    private int numCannons;
    private Cannon[] cannons;
    private double hitBoxLeft;
    private double hitBoxRight;
    private double hitBoxUp;
    private double hitBoxDown;
    private boolean defeated;

    public Fortress(int health, int level, int numCannons, double hitBoxLeft, double hitBoxRight, double hitBoxUp, double hitBoxDown) {
        this.health = health;
        this.level = level;
        this.numCannons = numCannons;
        this.hitBoxLeft = hitBoxLeft;
        this.hitBoxRight = hitBoxRight;
        this.hitBoxUp = hitBoxUp;
        this.hitBoxDown = hitBoxDown;
        defeated = false;
        cannons = new Cannon[numCannons];

        init();
    }

    private void init() {
        int side;
        for (int i = 0; i < numCannons; i++) {
            side = (int) (Math.random() * 4);
            if (side == 0) { //left
                cannons[i] = new Cannon(hitBoxLeft * DS.tileSize + 10 * DS.scale, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp) * DS.tileSize, 0, level * 4);
            } else if (side == 1) { //right
                cannons[i] = new Cannon(hitBoxRight * DS.tileSize - 10 * DS.scale, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp) * DS.tileSize, 0, level * 4);
            } else if (side == 2) { //up
                cannons[i] = new Cannon((Math.random() * (hitBoxLeft - hitBoxRight) + hitBoxLeft) * DS.tileSize, hitBoxUp * DS.tileSize + 10 * DS.scale, 0, level * 4);
            } else if (side == 3) { //down
                cannons[i] = new Cannon((Math.random() * (hitBoxLeft - hitBoxRight) + hitBoxLeft) * DS.tileSize, hitBoxDown * DS.tileSize - 10 * DS.scale, 0, level * 4);
            }
        }

    }

    public void updateFortess(Graphics2D g, double xPos, double yPos) {
        for (int i = 0; i < numCannons; i++) {
            double midX = cannons[i].getXPos();
            double midY = cannons[i].getYPos();
            double dev = Math.toDegrees(Math.abs(Math.atan((yPos - DS.gameHeight / 2) / (xPos - DS.gameWidth / 2))));
            if (yPos < midY) {
                if (xPos < midX) { //II
                    dev = 90 + dev;
                } else { //I
                    dev = 270 - dev;
                }
            } else {
                if (xPos < midX) { //III
                    dev = 90 - dev;
                } else { //IV
                    dev = 270 + dev;
                }
            }
            cannons[i].setAngle(dev);
            cannons[i].drawCannon(g);
        }
    }
    /*
    public static Fortress[] loadFortresses(){
        int numLines = 0;
        try{
            InputStream in = getClass().getResourceAsStream("/GameFiles/");
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            while (br.readLine() != null){
                numLines++;
            }
            br.close();
        }
        catch(IOException e){
        }
    }
*/
}
