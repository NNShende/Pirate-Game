//Daniel Papadopoulos, Nikhil Shende, Jamie Caille
//June 6, 2017
//Fortress class. This class runs the big buildings that defend against the player
package game;
//imports the use of colours, fonts, scaling drawing and loading images
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

public class Fortress {
    //variables for the fortress' health, max health, number of cannons, cannons, hit box values
    //whether or not it is defeated, position on the map, defeated image, cannon timer, and damage
    private int health;
    private final int MAX_HEALTH;
    private int numCannons;
    private Cannon[] cannons;
    private double hitBoxLeft;
    private double hitBoxRight;
    private double hitBoxUp;
    private double hitBoxDown;
    private boolean defeated;
    private int mapSecX;
    private int mapSecY;
    private Image defeatedIm;
    private double cannonTimer;
    private int damage;

    /**
     * constructor for the fortress
     * @param health the health
     * @param numCannons the number of cannons
     * @param hitBoxLeft the far left value of the hitbox
     * @param hitBoxRight the far right value of the hitbox
     * @param hitBoxUp the top of the hitbox
     * @param hitBoxDown the bottom of the hitbox
     * @param x the map section x value
     * @param y the map section y value
     * @param d  the damage of the cannons
     */
    public Fortress(int health, int numCannons, double hitBoxLeft, double hitBoxRight, double hitBoxUp, double hitBoxDown, int x, int y, int d) {
        //sets max health and starting health of the fortress
        this.MAX_HEALTH = health;
        this.health = health;
        //sets the number of cannons
        this.numCannons = numCannons;
        //sets the left hitbox value
        this.hitBoxLeft = hitBoxLeft;
        //sets the right hitbox value
        this.hitBoxRight = hitBoxRight;
        //sets the top hitbox valueu
        this.hitBoxUp = hitBoxUp;
        //sets the bottom hitbox value
        this.hitBoxDown = hitBoxDown;
        //creates a cannon array with space for the amount of cannons that the fortress has
        cannons = new Cannon[numCannons];
        //sets the defeated value to false (still alive)
        defeated = false;
        //sets the map section x and y values
        mapSecX = x;
        mapSecY = y;
        //loads the defeated image
        defeatedIm = loadImage("/GameFiles/Defeated.png");
        //sets the cannon damage
        damage = d;
        //initializes the fortress
        init();
    }
    /**
     * draws the health of the fortress
     * @param g the Graphics2D object used for drawing
     */
    public void drawHealth(Graphics2D g) {
        //gets the middle of the fortress x and y position
        double xPos = (hitBoxRight - hitBoxLeft) / 2 + hitBoxLeft;
        double yPos = (hitBoxDown - hitBoxUp) / 2 + hitBoxUp;
        //if the forterss hasn't been defeateed
        if (!defeated) {
            //sets the paint colour to grey
            g.setPaint(new Color(100, 100, 100, 50));
            //fills the background for the health bar 
            g.fillRect((int) Math.round(-150 * DS.scale + xPos), (int) Math.round(-20 * DS.scale + yPos), (int) Math.round(300 * DS.scale), (int) Math.round(40 * DS.scale));
            //sets the paint colour to red
            g.setPaint(Color.red);
            //fills over the background of the health bar based on the health of the fortress
            g.fillRect((int) Math.round(-150 * DS.scale + xPos), (int) Math.round(-20 * DS.scale + yPos), (int) Math.round(300 * DS.scale * (health * 1000 / MAX_HEALTH) / 1000), (int) Math.round(40 * DS.scale));
            //sets the paint colour to black
            g.setPaint(Color.black);
            //sets the font to a nice fresh comic sans
            g.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
            //draws the health value on the health bar
            g.drawString("Health: " + health + "/" + MAX_HEALTH, (int) Math.round(xPos - 157 * DS.scale), (int) Math.round(yPos - 40 * DS.scale));
            //adds to the cannon timer
            cannonTimer += 0.017;
            //if enough time has passed
            if (cannonTimer > 1) {
                //fires the cannon
                fireCannons();
                //resets the cannon timer
                cannonTimer = 0;
            }
            //if the fortress has been defeated
        } else {
            //creates an affine transformation object for the defeated imagee
            AffineTransform defeatedTrans = new AffineTransform();
            //moves the transform to the x and y position of the fotress
            defeatedTrans.translate(xPos, yPos);
            //scales the defeated image based on the screen size scale
            defeatedTrans.scale(DS.scale * 0.2, DS.scale * 0.2);
            //movees the transform to the centre of the fortress
            defeatedTrans.translate(-defeatedIm.getWidth(null) / 2, -defeatedIm.getHeight(null) / 2);
            //draws the defeated image based on the transformation
            g.drawImage(defeatedIm, defeatedTrans, null);
        }
    }
/**
 * initializer for the fortresses cannons
 */
    private void init() {
        //sets the cannon timer to 0
        cannonTimer = 0;
        //creates a new cannon array
        this.cannons = new Cannon[numCannons];
        //creates a variable for storing a random side
        int side;
        //loops through the cannon array
        for (int i = 0; i < cannons.length; i++) {
            //rolls a random number between 0 and 3
            side = (int) (Math.random() * 4);
            //if the side is 0
            if (side == 0) {
                //creates a new cannon somewhere along the left side of the fortress
                cannons[i] = new Cannon(hitBoxLeft + DS.tileSize / 2, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp), 0, 3);
                //if the side is 1
            } else if (side == 1) { //creates a new cannon somewhere along the right side
                cannons[i] = new Cannon(hitBoxRight - DS.tileSize / 2, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp), 0, 3);
                //if the side is 2
            } else if (side == 2) { //creates a new cannon somewhere along the top side 
                cannons[i] = new Cannon((Math.random() * (hitBoxRight - hitBoxLeft) + hitBoxLeft), hitBoxUp + DS.tileSize / 2, 0, 3);
                //if the side is 3
            } else if (side == 3) { //creates a new cannon somewhere along the bottom side
                cannons[i] = new Cannon((Math.random() * (hitBoxRight - hitBoxLeft) + hitBoxLeft), hitBoxDown - DS.tileSize / 2, 0, 3);
            }
        }

    }
/**
 * fires cannons
 */
    public void fireCannons() {
        //loops through the cannon array of the fortress
        for (int i = 0; i < cannons.length; i++) {
            //fires a cannonball from each cannon
            cannons[i].fireCannonball();
        }
    }
/**
 * updates and draws the fortress's cannons and health
 * @param g the Graphics2D object to draw with
 * @param xPos the x position of the fortress
 * @param yPos the y position of the fortress 
 */
    public void updateFortress(Graphics2D g, double xPos, double yPos) {
        //loops through the cannon array
        for (int i = 0; i < numCannons; i++) {
            //sets midX and midY to the x and y position of the current cannon
            double midX = cannons[i].getXPos();
            double midY = cannons[i].getYPos();
            //angle modifier based on where the cannon is in relation to the passed x and y position values (player ship values are passed)
            double dev = Math.toDegrees(Math.abs(Math.atan(Math.abs((yPos - midY)) / Math.abs((xPos - midX)))));
            //based on where the cannon is relative to the passed x and y values, it'll have to point
            //in a different direction in order to point towards the passed x and y values
            if (midX > xPos && midY > yPos) {
                dev += 90;
            } else if (midX < xPos && midY > yPos) {
                dev = 270 - dev;
            } else if (midX > xPos && midY < yPos) {
                dev = 90 - dev;
            } else if (midX < xPos && midY < yPos) {
                dev += 270;
            }
            dev += 90;
            //sets the cannon's angle to the calculated dev value
            cannons[i].setAngle(dev);
            //draws the cannon
            cannons[i].drawCannon(g);
        }
        //draws the health of the fortress
        drawHealth(g);
    }
/**
 * sets the map section x value
 * @param mapSecX the x value
 */
    public void setMapSecX(int mapSecX) {
        //sets the x value
        this.mapSecX = mapSecX;
    }
/**
 * sets the map section y value
 * @param mapSecY the y value
 */
    public void setMapSecY(int mapSecY) {
        //sets the y value
        this.mapSecY = mapSecY;
    }
/**
 * gets the map section x value
 * @return the x value
 */
    public int getMapSecX() {
        //returns the x value
        return mapSecX;
    }
/**
 * gets the map section y value
 * @return the y value
 */
    public int getMapSecY() {
        //returns the y valuee
        return mapSecY;
    }
/**
 * sets the left hit box value
 * @param hitBoxLeft the new value
 */
    public void setHitBoxLeft(double hitBoxLeft) {
        //sets the value
        this.hitBoxLeft = hitBoxLeft;
    }
/**
 * sets the right hit box value
 * @param hitBoxRight the new value
 */
    public void setHitBoxRight(double hitBoxRight) {
        //sets the value
        this.hitBoxRight = hitBoxRight;
    }
/**
 * sets the top hit box value
 * @param hitBoxUp the new value
 */
    public void setHitBoxUp(double hitBoxUp) {
        //sets the value
        this.hitBoxUp = hitBoxUp;
    }
/**
 * sets the bottom hit box value
 * @param hitBoxDown the new value
 */
    public void setHitBoxDown(double hitBoxDown) {
        //sets the value
        this.hitBoxDown = hitBoxDown;
    }
/**
 * gets the left hit box value
 * @return the hit box value
 */
    public double getHitBoxLeft() {
        //returns the value
        return hitBoxLeft;
    }
/**
 * gets the right hit box value
 * @return the hit box value
 */
    public double getHitBoxRight() {
        //returns the value
        return hitBoxRight;
    }
/**
 * gets the top hit box value
 * @return the hit box value
 */
    public double getHitBoxUp() {
        //returns the value
        return hitBoxUp;
    }
/**
 * gets the bottom hit box value
 * @return the hit box value
 */
    public double getHitBoxDown() {
        //returns the value
        return hitBoxDown;
    }
/**
 * sets the health of the fortress
 * @param health the desired health
 */
    public void setHealth(int health) {
        //sets the health
        this.health = health;
    }
/**
 * sets the number of cannons of the fortress
 * @param numCannons the desired number
 */
    public void setNumCannons(int numCannons) {
        //sets the number of cannons
        this.numCannons = numCannons;
        //reinitializes the cannons
        init();
    }
/**
 * gets the health of the fortress
 * @return the health
 */
    public int getHealth() {
        //returns the health
        return health;
    }
/**
 * sets the defeated status of the fortress
 * @param a boolean based on whether the fortress is defeated or not
 */
    public void setDefeated(boolean a) {
        //sets defeated to the new value
        defeated = a;
    }
/**
 * loads an image
 * @param src the source file for the image
 * @return the image loaded
 */
    public Image loadImage(String src) {
        //creates a variable for the image
        Image im = null;
        //try to do this
        try {
            //loads the image at the specified source
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
            //if somethinng goes wrong, do nothing
        } catch (Exception e) {

        }
        //returns the image
        return im;
    }
/**
 * get the max health of the fortress
 * @return the max health
 */
    public int getMaxHealth() {
        //returns the max health
        return MAX_HEALTH;
    }
/**
 * gets the cannon array
 * @return the cannon array
 */
    public Cannon[] getCannonArray() {
        //returns the cannon array
        return cannons;
    }
    /**
     * gets the damage of the fortress
     * @return the damage
     */
    public int getDamage(){
        //returns the damage
        return damage;
    }
    /**
     * sets the cannon array to a new array
     * @param c the new array
     */
    public void setCannonArray(Cannon[] c) {
        //sets the cannon array to the new array
        cannons = c;
    }

    /**
     * returns whether the fortresses has been defeated
     * @return defeated
     */
    public boolean isDefeated() {
        return defeated;
    }
    
    

}
