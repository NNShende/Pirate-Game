//Daniel Papadopoulos, Nikhil Shende, Jamie Caille
//June 12, 2017
//Class that handles most of the program function, acts as the JPanel, receives user input
//calls to many other classes and methods in order for the game to run
package game;

//imports the use of drawing functions, color, and font
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
//imports the use of drawing graphics on the jpanel
import java.awt.Graphics;
import java.awt.Graphics2D;
//imports the use of loading and rendering images
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
//imports the use of action and key listeners, to responds to happenings
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
//imports the use of image transformation
import java.awt.geom.AffineTransform;
//imports the use of file reader and writers
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.IOException;
//imports the use of array lists
import java.util.ArrayList;
//imports the use of popup windows
import javax.swing.JOptionPane;
//imports the use of JPanels for drawing
import javax.swing.JPanel;
//imports the use of timers for timing events
import javax.swing.Timer;

public class DS extends JPanel implements ActionListener, KeyListener {

    public static int screenWidth;
    public static int screenHeight;
    public static int gameWidth;
    public static int gameHeight;
    public static int tileSize;
    public static double scale;
    public static int gap;

    private Timer timer;
    private final int FPS = 60;
    private int delay = 1000 / FPS;

    private boolean right = false;
    private boolean left = false;
    private boolean up = false;
    private boolean down = false;
    private boolean space = false;
    private boolean escape = false;
    private boolean enter = false;
    private boolean inShop = false;

    private String saveData[][] = new String[3][2];

    private int timePirateNoise = 0;

    private int menuSelect = 1;
    private int optionSelect = 1;
    private boolean onLeft = true;
    private String[] menuPlay = {"Play!", "Start"};
    private String[] menuSettings = {"Settings!", "Ship Sail Colour"};
    private String[] menuCredits = {"Credits!"};
    private String[] menuExit = {"Close game?", "Exit", "Continue"};
    private String[][] menuSelections = {menuPlay, menuSettings, menuCredits, menuExit};

    private String line[] = new String[16];
    private int displace = 0;
    private Color textColour = new Color(230, 0, 0);

    private int[] timesToUpgrade = {4, 4, 1, 4};
    private double spawnChance = 0.5;

    public boolean gamePlay = false;
    public boolean gameStarted = false;
    public boolean gameHasBeenOpened = false;
    public boolean youLose = false;

    private Image death;
    private int deathTimer;
    private boolean gameOver = false;

    private Map map;
    private ExtraMap extraMap;
    private Ship playerShip;
    private ShipStats ss;
    private Ship enemyShip;
    private Fortress[] fortresses;

    private ArrayList<Player> playerList = new ArrayList<Player>();

    public static void getBestSize() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        screenWidth = screenSize.width;
        screenHeight = screenSize.height;

        int sizeFactorX = screenWidth / 19;
        int sizeFactorY = screenHeight / 10;

        if (sizeFactorX > sizeFactorY) {
            tileSize = sizeFactorY;
        } else {
            tileSize = sizeFactorX;
        }
        gameWidth = tileSize * 14;
        gameHeight = tileSize * 10;
        gap = (screenHeight - gameHeight) / 2;
        scale = tileSize / 128.0;
    }

    public DS() {
        init();
        addKeyListener(this);
        setFocusable(true);
        timer = new Timer(delay, this);
        timer.start();
    }

    public void init() {
        getBestSize();
        map = new Map();
        extraMap = new ExtraMap();
        playerShip = new PlayerShip(0, gameWidth / 5, gameHeight / 3, 10, 270, 100, 20);
        map.setMapSecX(2);
        map.setMapSecY(2);

        try {
            InputStream in = getClass().getResourceAsStream("/GameFiles/credits.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            for (int i = 0; i < line.length; i++) {
                line[i] = br.readLine();
            }

            br.close();
        } catch (IOException e) {
            System.out.println("Error: " + e);
        }

        ss = new ShipStats(0.02, 0, ((PlayerShip) playerShip).getGold());

        fortresses = loadFortresses();

        death = loadImage("/GameFiles/death.png");

    }
/**
 * draws everything in the program, calling appropriate methods
 * and does certain calculations for drawing
 * @param g_ the graphics object to do drawing with
 */
    public void paintComponent(Graphics g_) {
        //gets the Graphics2D object
        Graphics2D g = (Graphics2D) g_;
        //focuses on the window
        setFocusable(true);
        requestFocusInWindow();
        //sets anti aliasing to true 
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        //if the person has lost
        if (youLose) {
            //draws the death image screen
            g.drawImage(death, 0, 0, screenWidth, screenHeight, null);
            //adds to death timer
            deathTimer++;
            //if death timer is greater than 120 (2 seconds has passed)
            if (deathTimer > 120) {
                //puts the user at the exit part of the menu
                menuSelect = 4;
                optionSelect = 1;
                //if the game isn't over
                if (!gameOver) {
                    //the game is now over sorry
                    gameOver = true;
                    //activates the "exit the game" option
                    activateMenuAction();
                }
            }
            //otherwise if the game is not being played but the game isn't over (in menu screen)
        } else if (!gamePlay) {
            //sets the font to a nice comic sans
            g.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
            //draws the map for a nice background
            map.drawMap(g);
            //draws the title image
            Image titlePic = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/GameFiles/Title.png"));
            //creates an affine transform for the title image
            AffineTransform titleTrans = new AffineTransform();
            //moves the transform to the part of the screen where the title picture will be shown
            titleTrans.translate(gameWidth * 0.075, gap * 1.5);
            //scales the transform down based on the screen size
            titleTrans.scale(scale * 0.5, scale * 0.5);
            //draws the title image according to how the transformed was moved and scaled
            g.drawImage(titlePic, titleTrans, null);
            //draws rectangles for the four menu options
            g.fillRect(gameWidth / 8, gap + (5 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            g.fillRect(gameWidth / 8, gap + (8 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            g.fillRect(gameWidth / 8, gap + (11 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            g.fillRect(gameWidth / 8, gap + (14 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            //sets the color to white
            g.setColor(Color.WHITE);
            //draws the four menu options
            g.drawString("Start!", gameWidth / 2 - Math.round(90 * scale), gap + (6 * gameHeight / 17) + Math.round(scale * 20));
            g.drawString("Settings", gameWidth / 2 - Math.round(110 * scale), gap + (9 * gameHeight / 17) + Math.round(scale * 20));
            g.drawString("Credits", gameWidth / 2 - Math.round(102 * scale), gap + (12 * gameHeight / 17) + Math.round(scale * 20));
            g.drawString("Close", gameWidth / 2 - Math.round(73 * scale), gap + (15 * gameHeight / 17) + Math.round(scale * 20));
            //sets the colour to the designated text colour
            g.setColor(textColour);
            //sets the stroke to a new stroke size
            g.setStroke(new BasicStroke(10));
            //if the user tries to go off the bottom of the menu
            if (menuSelect == 5) {
                //puts them back on top of the menu
                menuSelect = 1;
                //if the user tries to go off the top of the menu
            } else if (menuSelect == 0) {
                //puts them back on bottom of the menu
                menuSelect = 4;
            }
            //if the current menu selection's options list isn't just the title
            if (menuSelections[menuSelect - 1].length != 1) {
                //if the user tries to go off the bottom of the option selections (on the right of the screen)
                if (optionSelect == menuSelections[menuSelect - 1].length) {
                    //moves them back to the first option
                    optionSelect = 1;
                    //if the user tries to go off the top of the option selections (on the right of the screen)
                } else if (optionSelect == 0) {
                    //moves them back to the last option
                    optionSelect = menuSelections[menuSelect - 1].length - 1;
                }
            }
            //if the user is on the right and there is options that can be selected
            if (!onLeft && menuSelections[menuSelect - 1].length != 1) {
                //draws a rectangle around the selected option
                g.drawRect(gameWidth + ((screenWidth - gameWidth) / 30), gap + (gameHeight / 10) * (optionSelect + 1) + ((2 / 3 * gap) + (gameHeight / 10)) / 2, ((screenWidth - gameWidth) * 9 / 10), (2 / 3 * gap) + (gameHeight / 10));
            }
            //draws a rectangle around the selected menu box on the left
            g.drawRect(gameWidth / 8, gap + ((2 + (3 * menuSelect)) * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            //draws the menu box's possible options on the right
            for (int i = 0; i < menuSelections[menuSelect - 1].length - 1; i++) {
                g.drawString(menuSelections[menuSelect - 1][i + 1], gameWidth + ((screenWidth - gameWidth) / 10), gap + (gameHeight / 10) * (i + 3) + Math.round(scale * 15));
            }
            //if the selected menu box is 2 (settings)
            if (menuSelect == 2) {
                //gets the player's sail image
                Image sail = ((PlayerShip) playerShip).getSailImage();
                //creates an affine transform for the sail
                AffineTransform sailTrans = new AffineTransform();
                //moves the transform to where the sail image will be drawn
                sailTrans.translate((screenWidth - gameWidth) / 2 + gameWidth, screenHeight / 2);
                //scales the transform up based on the screen size
                sailTrans.scale(scale * 5, scale * 5);
                //moves the transform to the centre of where the sail will be drawn
                sailTrans.translate(-sail.getWidth(null) / 2, 0);
                //draws the sail according to the sail transformations
                g.drawImage(sail, sailTrans, null);
            }
            //if the player is on the third menu box (credits)
            if (menuSelect == 3) {
                //adds to the displace, for moving the credits downwards
                displace += 2;
                //if the credits have fully scrolled
                if (displace > line.length * 70) {
                    //restarts the credit scrolling
                    displace = -screenHeight;
                }
                //loops through the credit line array
                for (int i = 0; i < line.length; i++) {
                    //draws each line of the credits, one below another
                    g.drawString(line[i], gameWidth + ((screenWidth - gameWidth) / 10), gap + (gameHeight / 10) * (i + 3) + Math.round(scale * 15) - displace);
                }
            }
            //sets the colur to black
            g.setColor(Color.BLACK);
            //draws a rectangle at the top of the right screen so the credits dont show behind the title text
            g.fillRect(gameWidth, 0, (screenWidth - gameWidth), gameHeight / 7 + gap);
            //sets the colour to the designated text colour
            g.setColor(textColour);
            //draws the title text for the selected menu box
            g.drawString(menuSelections[menuSelect - 1][0], gameWidth + ((screenWidth - gameWidth) / 10), gap + (gameHeight / 10));
            //if the game is bieng played
        } else if (gamePlay) {
            //if the player's health is below 0
            if (playerShip.getHealth() <= 0) {
                //they lose!
                youLose = true;
            }
            //draws the map
            map.drawMap(g);
            //draws the extra details around the map
            extraMap.drawExtraStuff(g, map.getMapSecX(), map.getMapSecY());
            //sets the spawn chance of enemy boats at 0.5
            double spawnChance = 0.5;
            //if the user leaves the bottom of the screen
            if (map.getMapSecY() < map.getMapSecYSize() - 1 && playerShip.getY() > gameHeight) {
                //moves the user down a map section
                map.setMapSecY(map.getMapSecY() + 1);
                //sets the user's y value so they're at the top of the screen
                playerShip.setY(gap);
                //clears any cannon balls the user fired
                playerShip.clearBalls();
                //deletes the enemy ship
                enemyShip = null;
                //possibly spawns an enemy ship
                spawnEnemyShip();
            }
            //if the user leaves the top of the screen
            if (map.getMapSecY() > 0 && playerShip.getY() < 0) {
                //moves the user up a map section
                map.setMapSecY(map.getMapSecY() - 1);
                //sets the user's y value so they're at the bottom of the screen
                playerShip.setY(gameHeight + gap);
                //clears any cannon balls the user fired
                playerShip.clearBalls();
                //deletes the enemy ship
                enemyShip = null;
                //possibly spawns an enemy ship
                spawnEnemyShip();
            }
            //if the user leaves the right of the screen
            if (map.getMapSecX() < map.getMapSecXSize() - 1 && playerShip.getX() > gameWidth) {
                //moves the user right a map section
                map.setMapSecX(map.getMapSecX() + 1);
                //sets the user's x value so they're at the left of the screen
                playerShip.setX(0);
                //clears any cannon balls the user fired
                playerShip.clearBalls();
                //deletes the enemy ship
                enemyShip = null;
                //possibly spawns an enemy ship
                spawnEnemyShip();
            }
            //if the user leaves the left of the screen
            if (map.getMapSecX() > 0 && playerShip.getX() < 0) {
                //moves the user left a map section
                map.setMapSecX(map.getMapSecX() - 1);
                //sets the user's x value so they're at the right of the screen
                playerShip.setX(gameWidth);
                //clears any cannon balls the user fired
                playerShip.clearBalls();
                //deletes the enemy ship
                enemyShip = null;
                //possibly spawns an enemy ship
                spawnEnemyShip();
            }
            //if there is an enemy ship available to draw
            if (enemyShip != null) {
                //draws the enemy ship
                ((EnemyShip) enemyShip).drawEnemyShip(g);
            }
            //sets the shipstats health to the player's health
            ss.setHealth(playerShip.getHealth());
            //sets the shipstats gold to the player's gold
            ss.setGold(((PlayerShip) playerShip).getGold());
            //draws the player's ship
            ((PlayerShip) playerShip).drawPlayerShip(g);
            //updates the ship stats (the text that shows stats for the ship)
            ss.update(g);
            //gets the x and y values of the current map section
            int x = map.getMapSecX();
            int y = map.getMapSecY();
            //loops through the fortress array
            for (int i = 0; i < fortresses.length; i++) {
                //if the fortress is located on the screen the user is currently on
                if (fortresses[i].getMapSecX() == x && fortresses[i].getMapSecY() == y) {
                    //updates the fortress on the player's screen
                    fortresses[i].updateFortress(g, playerShip.getX(), playerShip.getY() + gap);
                    //gets the hitbox values for the fortress
                    double x1 = fortresses[i].getHitBoxLeft();
                    double x2 = fortresses[i].getHitBoxRight();
                    double y1 = fortresses[i].getHitBoxUp();
                    double y2 = fortresses[i].getHitBoxDown();
                    //updates the fortress's health
                    fortresses[i] = playerShip.updateHealth(fortresses[i]);
                    //get's the player's ship's cannon array
                    Cannon c[] = playerShip.getCannonArray();
                    //loops through the length of the cannon array (all the cannons)
                    for (int j = 0; j < c.length; j++) {
                        //loops through each cannon's cannonballs
                        for (int k = 0; k < Cannon.maxBalls; k++) {
                            //sets cannon cc to the user's cannon at j
                            Cannon cc = playerShip.getCannon(j);
                            //if there is a cannon there
                            if (cc != null) {
                                //gets the cannonball in the cannon at k
                                Cannonball cb = cc.getCannonball(k);
                                //if there is a cannonball there
                                if (cb != null) {
                                    //if the player's cannonball is within the bounds of the fortress
                                    if (cb.getXPos() > x1 && cb.getXPos() < x2 && cb.getYPos() > y1 && cb.getYPos() < y2) {
                                        //deletes the cannonball
                                        playerShip.deleteCannonball(j, k);
                                        //subtracts the cannonball's damage from the fortress health
                                        fortresses[i].setHealth(fortresses[i].getHealth() - playerShip.getDamage());
                                        //if the fortress hsa a health below 0 and is not defeated yet
                                        if (fortresses[i].getHealth() <= 0 && fortresses[i].isDefeated() == false) {
                                            //sets the fortress to being defeated
                                            fortresses[i].setDefeated(true);
                                            //adds one fifth of the fortress's health to the player's gold
                                            ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() + (int) Math.round(fortresses[i].getMaxHealth() * 0.2));
                                            //heals the player back to max health
                                            playerShip.setHealth(100);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //adds to the pirate noise counter
            timePirateNoise++;
            //if the pirate noise counter is high enough (10m seconds)
            if (timePirateNoise >= 600) {
                //resets the counter
                timePirateNoise = 0;
                //gets a random number between 0 and 1
                double noise = Math.random();
                //if the random number is below 0.25
                if (noise < 0.25) {
                    //plays the first pirate noise
                    playerShip.so.playPirate1();
                    //if the random number is 0.25-05
                } else if (noise < 0.5) {
                    //plays the second pirate noise
                    playerShip.so.playPirate2();
                    //if the random number is 0.5-0.75
                } else if (noise < 0.75) {
                    //plays the third noise
                    playerShip.so.playPirate3();
                    //if the random number is 0.75-1
                } else {
                    //p;ays the fourth noise
                    playerShip.so.playPirate4();
                }
            }
            //draws the sidebar
            map.drawSidebar(g);
            //if the player is on the centre map section
            if (map.getMapSecX() == 2 && map.getMapSecY() == 2) {
                //draws the shop text pointing to the shop
                map.drawShopText(g);
                //if the player is docked and within the bounds of the shop
                if ((playerShip.getFrontDocked() || playerShip.getBackDocked()) && ((int) Math.floor(playerShip.getX() / tileSize) == 6) && ((int) Math.floor(playerShip.getY() / tileSize) == 5)) {
                    //if the player isn't in the shop
                    if (!inShop) {
                        //selects the first shop item
                        menuSelect = 0;
                        //sets the status of the player being in the shop to true
                        inShop = true;
                    }
                    //draws the shop with the current ship stats
                    ss.drawShop(g, menuSelect);
                    //loops through the four shop options
                    for (int i = 0; i < 4; i++) {
                        //if an item can no longer be upgraded
                        if (timesToUpgrade[i] == 0) {
                            //draws over the option, saying that item is sold out
                            ss.drawSoldOut(g, i);
                        }
                    }
                    //if the user is in the shop
                } else {
                    //resets the selected shop item
                    menuSelect = 0;
                    //leaves the shop
                    inShop = false;
                }
            }
            //sets the paint colour to black
            g.setPaint(Color.black);
            //draws the gap at the top of the screen
            g.fillRect(0, 0, screenWidth, gap);
            //draws the gap at the bottom of the screen
            g.fillRect(0, screenHeight - gap, screenWidth, gap);
        }
    }

    public void upgradeShip(int sel) {
        if (timesToUpgrade[sel] > 0) {
            if (sel == 0) {
                if (((PlayerShip) playerShip).getGold() >= 10) {
                    playerShip.setMoveSpeed(playerShip.getMoveSpeed() + 2);
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 10);
                    timesToUpgrade[sel]--;
                }
            } else if (sel == 1) {
                if (((PlayerShip) playerShip).getGold() >= 20) {
                    playerShip.setDamage(playerShip.getDamage() + 5);
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 20);
                    timesToUpgrade[sel]--;
                }
            } else if (sel == 2) {
                if (((PlayerShip) playerShip).getGold() >= 50) {
                    playerShip.addCannons();
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 50);
                    timesToUpgrade[sel]--;
                }
            } else if (sel == 3) {
                if (((PlayerShip) playerShip).getGold() >= 15) {
                    ss.setIncTime(ss.getIncTime() + 0.02);
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 15);
                    timesToUpgrade[sel]--;
                }
            }

        }
    }

    public void activateMenuAction() {
        if (menuSelect == 1) {
            gamePlay = true;
            gameStarted = true;
            gameHasBeenOpened = true;
        } else if (menuSelect == 2) {
            int col = ((PlayerShip) playerShip).getSailNumber();
            if (col < 3) {
                ((PlayerShip) playerShip).setSailNumber(col + 1);
            } else {
                ((PlayerShip) playerShip).setSailNumber(0);
            }
        } else if (menuSelect == 4) {
            if (optionSelect == 2) {
                if (gameStarted) {
                    gamePlay = true;
                } else {
                    menuSelect = 1;
                    onLeft = true;
                }
            } else {

                readHighScoreFile();
                if (gameHasBeenOpened) {
                    String name = JOptionPane.showInputDialog("Enter your name");
                    if (name.isEmpty()) {
                        name = "Too lazy to enter a name";
                    }
                    playerList.add(new Player(((PlayerShip) playerShip).getEarnedGold(), name));

                    sortPlayers(0, playerList.size() - 1);
                    for (int i = 0; i < playerList.size() - 1; i++) {
                        if (playerList.get(i).getName() == null) {
                            playerList.remove(i);
                        }
                    }
                    writeHighScoreFile();
                }
                String output = "";
                if (playerList.size() > 0) {
                    output += "Top 5 Players:\n";
                } else {
                    output += "No high scores have been recorded";
                }
                for (int i = 0; i < playerList.size(); i++) {
                    String n = playerList.get(i).getName();
                    String s = playerList.get(i).getScore() + "";
                    output += n + ": " + s + "\n";
                    if (i >= 4) {
                        i = playerList.size();
                    }
                }
                JOptionPane.showMessageDialog(null, output);
                System.exit(0);

            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        setFocusable(true);
        requestFocusInWindow();
        repaint();
        if (!playerShip.getFrontDocked() && !playerShip.getBackDocked()) {
            if (right && down) {
                playerShip.decR(1);
            } else if (right && up) {
                playerShip.incR(1);
            }
            if (left && down) {
                playerShip.incR(1);
            } else if (left && up) {
                playerShip.decR(1);
            }
        }
        if (up && !playerShip.getFrontDocked()) {
            playerShip.decX();
            playerShip.incY();
        }
        if (down && !playerShip.getBackDocked()) {
            playerShip.incX();
            playerShip.decY();
        }

        if (enemyShip != null) {
            enemyShip = playerShip.updateHealth(enemyShip);
            playerShip = enemyShip.updateHealth(playerShip);
        }

        try {
            if (up && map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) != 0 && playerShip.getBackDocked() == false) {
                playerShip.setFrontDocked(true);
            } else if (map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) == 0) {
                playerShip.setFrontDocked(false);
            }
            if (down && map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) != 0 && playerShip.getFrontDocked() == false) {
                playerShip.setBackDocked(true);
            } else if (map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) == 0) {
                playerShip.setBackDocked(false);
            }
            if (enemyShip != null) {
                if (!enemyShip.getFrontDocked() && map.getTile((int) Math.floor(enemyShip.getX() / tileSize), (int) Math.floor(enemyShip.getY() / tileSize)) != 0) {
                    enemyShip.setFrontDocked(true);
                } else if (enemyShip.getFrontDocked() && map.getTile((int) Math.floor(enemyShip.getX() / tileSize), (int) Math.floor(enemyShip.getY() / tileSize)) != 0) {
                    enemyShip.setFrontDocked(false);
                }

                if (enemyShip.getHealth() <= 0) {
                    enemyShip = null;
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() + 5);
                    if (playerShip.getHealth() > 70) {
                        playerShip.setHealth(100);
                    } else {
                        playerShip.setHealth(playerShip.getHealth() + 30);
                    }

                }
            }

        } catch (Exception ex) {
        }

    }
/**
 * activates when a key is typed, doesn't do anything but must be here
 * @param e the keyevent when the key is typed
 */
    @Override
    public void keyTyped(KeyEvent e) {
    }
/**
 * does stuff when a key is pressed down
 * @param e 
 */
    @Override
    public void keyPressed(KeyEvent e) {
        //gets the key entered
        int key = e.getKeyCode();
        //if the user is currently not playing the game (in the menu)
        if (!gamePlay) {
            //if the user is in the left of the menu
            if (onLeft) {
                //if the user pressed the down key
                if (key == KeyEvent.VK_DOWN) {
                    //moves down the menu
                    menuSelect++;
                    //if the user is on the credits menu
                    if (menuSelect == 3) {
                        //resets the credits menu to scroll from the top
                        displace = 0;
                    }
                }
                //if the user pressed the up key
                if (key == KeyEvent.VK_UP) {
                    //moves the user up the menu
                    menuSelect--;
                    //if the user is on the credits menu
                    if (menuSelect == 3) {
                        //resets the credits menu to scroll from the top
                        displace = 0;
                    }
                }
                //if the key is the right arrow and the user isnt on the credits
                if (key == KeyEvent.VK_RIGHT && menuSelect != 3) {
                    //moves them to the right of the menu
                    onLeft = false;
                }
            //if the key is the left key
            } else if (key == KeyEvent.VK_LEFT) {
                //moves them onto the left of the menu if they already aren't there
                onLeft = true;
                //resets the option select (for which option is selected on the right)
                optionSelect = 1;
                //if the user isn't on the left and presses up
            } else if (key == KeyEvent.VK_UP) {
                //moves to the previous selected option
                optionSelect--;
                //if the user isn't on the left and presses down
            } else if (key == KeyEvent.VK_DOWN) {
                //moves to the next selected option
                optionSelect++;
                //if the user isnt on the left and presses enter
            } else if (key == KeyEvent.VK_ENTER) {
                //selects that option as the task at hand
                activateMenuAction();
            }
            //if the user isn't in the menu AKA THEY'RE IN THE GAME
        } else {
            //if the user presses a
            if (key == KeyEvent.VK_A) {
                //start rotating left
                left = true;
            }
            //if the user pressed d
            if (key == KeyEvent.VK_D) {
                //start rotating right
                right = true;
            }
            //if the user presses w
            if (key == KeyEvent.VK_W) {
                //start= moving forward
                up = true;
            }
            //if the user presses s
            if (key == KeyEvent.VK_S) {
                //start moving backward
                down = true;
            }
            //if the user presses space
            if (key == KeyEvent.VK_SPACE) {
                //try to fire the cannons, make space true
                space = true;
            }
            //if the user is in the shop
            if (inShop) {
                //if the user pressed the down arrow
                if (key == KeyEvent.VK_DOWN) {
                    //selects the next menu option
                    menuSelect++;
                    //if the user pressed the up arrow
                } else if (key == KeyEvent.VK_UP) {
                    //selects the previous menu option
                    menuSelect--;
                }
                //if the user went past the bottom of the shop
                if (menuSelect > 3) {
                    //moves them back to the top
                    menuSelect = 0;
                    //if the user went above the top of the shop
                } else if (menuSelect < 0) {
                    //moves them back to the bottom
                    menuSelect = 3;
                }
                //if the user pressed enter 
                if (key == KeyEvent.VK_ENTER) {
                    //tries to buy item, sets enter to true
                    enter = true;
                }
            }
            //if the user pressed escape
            if (key == KeyEvent.VK_ESCAPE) {
                //sets escape to true
                escape = true;
            }
        }

    }
/**
 * activates whenever a key is released
 * @param e 
 */
    @Override
    public void keyReleased(KeyEvent e) {
        //if the game is being played
        if (gamePlay) {
            //gets the keycode of the released key
            int key = e.getKeyCode();
            //if the key was a
            if (key == KeyEvent.VK_A) {
                //the player stops going left
                left = false;
            }
            //if the key was d
            if (key == KeyEvent.VK_D) {
                //the player stops going right
                right = false;
            }
            //if the key was w
            if (key == KeyEvent.VK_W) {
                //the player stops goingr up
                up = false;
            }
            //if the key was s
            if (key == KeyEvent.VK_S) {
                //the player stops going down
                down = false;
            }
            //if the key was space and space was being pressed (just in case the user opens the program holding space)
            if (key == KeyEvent.VK_SPACE && space) {
                //turns off the space
                space = false;
                //if the ship is ready to fire
                if (ss.getCurTime() >= 1) {
                    //fires the cannons
                    playerShip.fireCannons();
                    //restarts the player's cannon timer
                    ss.setCurTime(0);
                    //plays the cannon firing noise
                    playerShip.so.playCannon();
                }
            }
            //if the user released the escape key
            if (key == KeyEvent.VK_ESCAPE) {
                //sets escape back to false
                escape = false;
                //pauses gameplay
                gamePlay = false;
                //selects the exit option of the menu
                menuSelect = 4;
                //puts them on the right side of the menu
                onLeft = false;
                //selects the first option (exit)
                optionSelect = 1;
            }
            //if the user is in the shop
            if (inShop) {
                //if the key was enter
                if (key == KeyEvent.VK_ENTER) {
                    //upgrades the ship according to the option hovered over
                    upgradeShip(menuSelect);
                }
            }
        }
    }
/**
 * spawns an enemy ship
 */
    public void spawnEnemyShip() {
        //if the user isn't in the starting area
        if (!(map.getMapSecX() == 2 && map.getMapSecY() == 2)) {
            //gets a random position for the boat to spawn in
            double xRan = Math.random() * gameWidth;
            double yRan = Math.random() * gameHeight;
            //if the random roll is within the bounds of the spawn chance percentage
            if (Math.random() < spawnChance) {
                //while the boat has an x and y position that would place it in land
                while (map.getTile((int) Math.floor(xRan / tileSize), (int) Math.floor(yRan / tileSize)) != 0) {
                    //rerolls the spawn position
                    xRan = (Math.random() * gameWidth);
                    yRan = (Math.random() * gameHeight);
                }
                //creates a new enemy boat at the x and y position, randomish speed, random angle, and 100 health
                enemyShip = new EnemyShip(xRan, yRan + gap, (int) (Math.random() * 5) + 4, Math.random() * 360, 100);

            }
        }

    }
/**
 * loads the fortress data and puts them into an array
 * @return the loaded array
 */
    public Fortress[] loadFortresses() {
        //initializes the variable for the number of forts
        int numForts = 0;
        Fortress[] f = null;
        //try to do this
        try {
            //opens an input stream for reading from the fortress hit box file
            InputStream in = getClass().getResourceAsStream("/GameFiles/FortressHitboxData.txt");
            //opens a buffered reader to read from the text file
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            //gets the number of forts from the first line in the file
            numForts = Integer.parseInt(br.readLine());
            //creates a fortress array the size of the number of fortress
            f = new Fortress[numForts];
            //creates an array for holding info about the array
            int[] nums = new int[9];
            //loops the amount of time that there are fortresses
            for (int i = 0; i < numForts; i++) {
                //reads the fortress number, just for organization
                br.readLine();
                //reads the map section that the fortress is in
                String line1[] = br.readLine().split(" ");
                //puts the map section x position in the nums array
                nums[0] = Integer.parseInt(line1[0]);
                //puts the map section y position in the nums array
                nums[1] = Integer.parseInt(line1[1]);
                //reads the position of the top left corner of the fortress
                String line2[] = br.readLine().split(" ");
                //puts the top left corner x position in the nums array
                nums[2] = tileSize * Integer.parseInt(line2[0]);
                //puts the top left corner y position in the nums array
                nums[3] = tileSize * Integer.parseInt(line2[1]) + gap;
                //reads the position of the bottom right corner of the fortress
                String line3[] = br.readLine().split(" ");
                //puts the bottom right corner x position in the nums array
                nums[4] = tileSize * (Integer.parseInt(line3[0]) + 1);
                //puts the bottom right corner  yposition in the nums array
                nums[5] = tileSize * (Integer.parseInt(line3[1]) + 1) + gap;
                //reads the number of cannons and puts it in the num array
                nums[6] = Integer.parseInt(br.readLine());
                //reads the health and puts it in the num array
                nums[7] = Integer.parseInt(br.readLine());
                //reads the cannon damage and puts it in the num array
                nums[8] = Integer.parseInt(br.readLine());
                //creates a fortress at the i'th index using the info gathered about the fortress
                f[i] = new Fortress(nums[7], nums[6], nums[2], nums[4], nums[3], nums[5], nums[0], nums[1], nums[8]);
            }
            //closes the buffered reader
            br.close();
            //
        } catch (IOException e) {
        }
        return f;
    }
/**
 * writes to the high score file
 */
    public void writeHighScoreFile() {
        //try to do this
        try {
            //opens a file writer to overwrite the high score file
            PrintWriter writer = new PrintWriter("HighScores.txt", "UTF-8");
            //loops through the player list array
            for (int i = 0; i < playerList.size(); i++) {
                //writes the players name and score in the high score file
                writer.println(playerList.get(i).getName());
                writer.println(playerList.get(i).getScore());
            }
            //closes the writer
            writer.close();
            //if something went wrong
        } catch (IOException e) {
            //print the error
            System.out.println(e);
        }
    }
/**
 * reads from the high score file
 */
    public void readHighScoreFile() {
        //tries to do this
        try {
            //opens an inputstream for the high scores text file
            InputStream in = new FileInputStream("HighScores.txt");
            //opens a bufferedreader to read from the file
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            //boolean for seeing whether we are at the end of the file
            boolean eof = false;
            //string for the player name
            String playerName = "";
            //string for the player's score
            int playerScore = 0;
            //while we aren't at the end of the file
            while (!eof) {
                //read the player name
                playerName = br.readLine();
                //if there is no name there
                if (playerName == null) {
                    //we reached the end of the file
                    eof = true;
                    //otherwise
                } else {
                    //read the player score
                    playerScore = Integer.parseInt(br.readLine());
                }
                //adds the read player to the playerList with their name and score
                playerList.add(new Player(playerScore, playerName));
            }
            //closes the reader
            in.close();
            //if something went wrong
        } catch (Exception e) {
            //prints out the error
            System.out.println("Error: " + e);
        }
    }
/**
 * sorts the player scores from the playerList array list
 * @param low the low bound of the playerList array list
 * @param high the high bound of the playerList array list
 */
    private void sortPlayers(int low, int high) {
        int l = low; //left side tracker
        int r = high; //right side tracker
        int p = playerList.get(low + (high - low) / 2).getScore(); //pivot of the array
        Player temp; //temporary number for swapping elements in the array

        while (l <= r) { //while the left side tracker is still less than or equal to the right side tracker position
            while (playerList.get(l).getScore() > p) { //while the left side element is where it's supposed to be
                l++; //move right one
            }
            while (playerList.get(r).getScore() < p) { //while the right side element is where it's supposed to be
                r--; //move left one
            }

            if (l <= r) { //if the left side tracker is still less than or equal the right side
                //swap the elements at i and k
                temp = playerList.get(l);
                playerList.set(l, playerList.get(r));
                playerList.set(r, temp);
                l++; //move i right one
                r--; //move k left one
            }

        }

        if (low < r) { //if the lower limit is less than the right positon marker,
            sortPlayers(low, r); //run quiksort from low to right
        }
        if (l < high) { //if the left position marker is less than the upper marker
            sortPlayers(l, high); //run quiksort from left to high
        }
    }
/**
 * loads images
 * @param src the source file
 * @return the image
 */
    public Image loadImage(String src) {
        //declares an Image for storing the image
        Image im = null;
        //attempt this
        try {
            //loads an image from the source file
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
            //if the loading failed, do nothing
        } catch (Exception e) {

        }
        //return the image
        return im;
    }

}
