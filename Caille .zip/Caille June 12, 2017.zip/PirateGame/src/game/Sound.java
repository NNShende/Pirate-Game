//Daniel Papadoulos, Nikhil Shende, Jamie Caille
//June 6, 2017
//Class for playing sounds in the game. This includes sounds for firing cannons,
//getting hit, background music, and ambient noises
package game;

//imports the use of URL loading, classes used for playing audio, and a variable
//for playing audio continuously
import java.net.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import static javax.sound.sampled.Clip.LOOP_CONTINUOUSLY;

class Sound {

    public Sound() {
    }

    /**
     * class for playing cannon noise
     */
    public void playCannon() {
        try {
            //loads the resource for the cannon noise
            URL url = this.getClass().getResource("/game/cannon.wav");
            //opens a stream for the audio
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            //creates a clip for the sound
            Clip clip = AudioSystem.getClip();
            //opens the audio clip
            clip.open(audio);
            //starts the audio
            clip.start();
        } 
        //if the loading didn't work
        catch (Exception e) {
            //prints out the error
            System.out.println(e);
        }
    }
/**
 * plays sound for when a ship is hit
 */
    public void playHit() {
        try {
            //opens a resource for the hit noise
            URL url = this.getClass().getResource("/game/hit.wav");
            //refer to playCannon()
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
/**
 * plays the background noise
 */
    public void playBG() {
        try {
            //opens a resource for the background music
            URL url = this.getClass().getResource("/game/bg.wav");
            //refer to playCannon()
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            //loops the audio indefinitely
            clip.loop(LOOP_CONTINUOUSLY);
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
/**
 * plays the first ambient pirate noise
 */
    public void playPirate1() {
        try {
            //loads the pirate noise
            URL url = this.getClass().getResource("/game/pirate1.wav");
            //refer to playCannon()
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
/**
 * plays the second ambient pirate noise
 */
    public void playPirate2() {
        try {
            //loads the pirate noise
            URL url = this.getClass().getResource("/game/pirate2.wav");
            //refer to playCannon()
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
/**
 * loads the third pirate noise
 */
    public void playPirate3() {
        try {
            //loads the third ambient noise
            URL url = this.getClass().getResource("/game/pirate3.wav");
            //refer to playCannon()
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
/**
 * loads the fourth pirate noise
 */
    public void playPirate4() {
        try {
            //loads the fourth ambient noise
            URL url = this.getClass().getResource("/game/pirate4.wav");
            //refer to playCannon()
            AudioInputStream audio = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
