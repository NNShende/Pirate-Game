//Daniel Papadopoulos, Nikhil Shende, Jamie Caille
//June 6, 2017
//Class for players. Manages the score and the name of the player
package game;

public class Player {
    //variables for the player's name and score
    private int score;
    private String name;
    /**
     * constructor for the player
     * @param s the player's score
     * @param n the player's name
     */
    public Player(int s, String n){
        score = s;
        name = n;
    }
    /**
     * gets the score of the player
     * @return the score
     */
    public int getScore() {
        //returns the player's score
        return score;
    }
    /**
     * gets the name of the player
     * @return the name
     */
    public String getName() {
        //returns the player's name
        return name;
    }
    
}