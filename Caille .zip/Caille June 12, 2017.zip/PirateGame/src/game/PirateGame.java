//Daniel Papadopoulos, Nikhil Shende, Jamie Caille
//June 6, 2017
//Welcome to Pirate Game! A swashbuckling adventure of fun and cannons awaits ye!
//This class launches the game through the JFrame
package game;
//imports the use of JFrames
import javax.swing.JFrame;

public class PirateGame {

    public static void main(String[] args) {
        //creates a new JFrame
        JFrame frame = new JFrame();
        //creates a new DS (JPanel to go on the JFrame)
        DS ds = new DS();
        //sets the size of the JFrame to the size of the JPanel
        frame.setSize(DS.screenWidth, DS.screenHeight);
        //disallows the JFrame from being resizeable
        frame.setResizable(false);
        //hides the title bar and things around the JFrame
        frame.setUndecorated(true);
        //centres the JFrame on the screen, making it fill the entire screen
        frame.setLocationRelativeTo(null);
        //sets it so that when the JFrame is closed, the JFrame exits oepration
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //sets the title of the JFrame
        frame.setTitle("Pirate Game");
        //adds the JPanel to teh JFrame
        frame.add(ds);
        //sets the JFrame to being visible
        frame.setVisible(true); 
        //creates a new sound object and plays the background music
        Sound so = new Sound();
        so.playBG();

    }
    
    

}
