package game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

public class ShipStats {

    private double incTime;
    private double curTime;
    private int gold;
    private Image bar;
    private Image barBG;

    public ShipStats(double incTime, double curTime, int gold) {
        this.incTime = incTime;
        this.curTime = curTime;
        this.gold = gold;
        bar = loadImage("/GameFiles/FireBar.png");
        barBG = loadImage("/GameFiles/FireBarBG.png");
    }
    
    public double getCurTime(){
        return curTime;
    }
    
    public void setCurTime(double val){
        curTime = val;
    }

    public void update(Graphics2D g) {
        if (curTime < 1) {
            curTime += incTime;
        }
        drawShipStats(g);
    }

    public void drawShipStats(Graphics2D g) {
        AffineTransform barBGTrans = new AffineTransform();
        barBGTrans.translate(DS.gameWidth / 2-160, DS.gap + DS.gameHeight - 50);
        barBGTrans.scale(1, 0.8);
        g.drawImage(barBG, barBGTrans, null);
        
        AffineTransform barTrans = new AffineTransform();
        barTrans.translate(DS.gameWidth / 2-160, DS.gap + DS.gameHeight - 50);
        barTrans.scale(curTime, 0.8);
        g.drawImage(bar, barTrans, null);
        
        
        g.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        g.setPaint(Color.red);
        g.drawString("Cannon Charge", DS.gameWidth/2-55, DS.gap + DS.gameHeight - 55);
        
        g.setPaint(new Color(212,175,55));
        g.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        g.drawString("Gold: "+gold, 10, DS.gap+30);
        
        
    }
    
    public int getGold(){
        return gold;
    }
    
    public void setGold(int val){
        gold = val;
    }
    

    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {

        }
        return im;
    }

}
