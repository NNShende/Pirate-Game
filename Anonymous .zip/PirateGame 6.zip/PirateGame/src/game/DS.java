package game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;
import javax.swing.Timer;

public class DS extends JPanel implements ActionListener, KeyListener {

    public static int screenWidth;
    public static int screenHeight;
    public static int gameWidth;
    public static int gameHeight;
    public static int tileSize;
    public static double scale;
    public static int gap;

    private Timer timer;
    private final int FPS = 60;
    private int delay = 1000 / FPS;

    private boolean right = false;
    private boolean left = false;
    private boolean up = false;
    private boolean down = false;
    private boolean space = false;

    private Map map;
    private Ship playerShip;

    public static void getBestSize() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        screenWidth = screenSize.width;
        screenHeight = screenSize.height;
        
        int sizeFactorX = screenWidth / 19;
        int sizeFactorY = screenHeight / 10;

        if (sizeFactorX > sizeFactorY) {
            tileSize = sizeFactorY;
        } else {
            tileSize = sizeFactorX;
        }
        gameWidth = tileSize * 14;
        gameHeight = tileSize * 10;
        gap = (screenHeight - gameHeight)/2;
        scale = tileSize/128.0 ;
    }

    public DS() {
        init();
        addKeyListener(this);
        setFocusable(true);
        timer = new Timer(delay, this);
        timer.start();
    }

    public void init() {
        getBestSize();
        map = new Map();
        playerShip = new PlayerShip(2, 0, gameWidth / 5, gameHeight / 3, 10, 270, 100);
        
    }

    public void paintComponent(Graphics g_) {
        Graphics2D g = (Graphics2D) g_;
        map.drawMap(g);

        if (map.getMapSecY() < map.getMapSecYSize() - 1 && playerShip.getY() > gameHeight) {
            map.setMapSecY(map.getMapSecY() + 1);
            playerShip.setY(gap);
            playerShip.clearBalls();
        }
        if (map.getMapSecY() > 0 && playerShip.getY() < 0) {
            map.setMapSecY(map.getMapSecY() - 1);
            playerShip.setY(gameHeight+gap);
            playerShip.clearBalls();
        }
        if (map.getMapSecX() < map.getMapSecXSize() - 1 && playerShip.getX() > gameWidth) {
            map.setMapSecX(map.getMapSecX() + 1);
            playerShip.setX(0);
            playerShip.clearBalls();
        }
        if (map.getMapSecX() > 0 && playerShip.getX() < 0) {
            map.setMapSecX(map.getMapSecX() - 1);
            playerShip.setX(gameWidth);
            playerShip.clearBalls();
        }

        try {
            if (up && map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) != 0 && playerShip.getBackDocked() == false) {
                playerShip.setFrontDocked(true);
            } else if (map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) == 0){
                playerShip.setFrontDocked(false);
            }
            if (down && map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) != 0&& playerShip.getFrontDocked() == false) {
                playerShip.setBackDocked(true);
            } else if (map.getTile((int) Math.round(playerShip.getX()) / tileSize, (int) Math.round(playerShip.getY()) / tileSize) == 0){
                playerShip.setBackDocked(false);
            }
        } catch (Exception e) {
        }

        playerShip.drawBoat(g);
        
        map.drawSidebar(g);
        g.setPaint(Color.black);
        g.fillRect(0,0,screenWidth, gap);
        g.fillRect(0, screenHeight-gap, screenWidth, gap);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        repaint();
        if (!playerShip.getFrontDocked() && !playerShip.getBackDocked()) {
            if (right && (up || down)) {
                playerShip.incR();
            }
            if (left && (up || down)) {
                playerShip.decR();
            }
        }
        if (up && !playerShip.getFrontDocked()) {
            playerShip.decX();
            playerShip.incY();
        }
        if (down && !playerShip.getBackDocked()) {
            playerShip.incX();
            playerShip.decY();
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            left = true;
        }

        if (key == KeyEvent.VK_RIGHT) {
            right = true;
        }

        if (key == KeyEvent.VK_UP) {
            up = true;
        }

        if (key == KeyEvent.VK_DOWN) {
            down = true;
        }
        
        if (key == KeyEvent.VK_SPACE){
            space = true;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            left = false;
        }

        if (key == KeyEvent.VK_RIGHT) {
            right = false;
        }

        if (key == KeyEvent.VK_UP) {
            up = false;
        }

        if (key == KeyEvent.VK_DOWN) {
            down = false;
        }
        
        if (key == KeyEvent.VK_SPACE && space){
            space = false;
            playerShip.fireCannons();
        }
    }

}
