//Daniel Papadopoulos, Nikhil Shende, Jamie Caille
//June 6, 2017
//Class for the player's ship, includes more customizability and graphics specific
//to the player's ship, as well as gold
package game;
//imports the use of colours, drawing scaling and loading images

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

public class PlayerShip extends Ship {

    // variables for the sail that the palyer chooses, the player ship and sail image
    // and amount of gold
    private int sailNumber;
    private Image playerShip;
    private Image sail;
    private int gold;
    private int earnedGold;

    /**
     * constructor for the player ship
     *
     * @param sailNumber the chosen sail
     * @param xPos the x position
     * @param yPos the y position
     * @param mS movement speed
     * @param a angle
     * @param h health
     * @param g gold
     */
    public PlayerShip(int sailNumber, double xPos, double yPos, double mS, double a, int h, int g) {
        //calls the super constructor for constructing a ship with the given x pos, y pos, movement speed
        //angle, and health
        super(xPos, yPos, mS, a, h);
        //sets the sail number
        this.sailNumber = sailNumber;
        //sets the player ship and sail images
        playerShip = loadImage("/GameFiles/Ship_parts/hullLarge (1).png");
        sail = loadImage("/GameFiles/Ship_parts/sailLarge (10).png");
        //sets the gold
        gold = g;
        earnedGold = g;
    }

    /**
     * draws the player's ship
     *
     * @param g
     */
    public void drawPlayerShip(Graphics2D g) {
        //creates an affine transform object for scaling and rotating the ship
        AffineTransform boatTrans = new AffineTransform();
        //moves the transform to the x and y pos of the boat
        boatTrans.translate(xPos, yPos);
        //rotates the transform
        boatTrans.rotate(Math.toRadians(angle));
        //scales the transform based on the screen scale
        boatTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        //translates the transform so the image centre is the x and y position of the boat
        boatTrans.translate(-playerShip.getWidth(null) / 2, -playerShip.getHeight(null) / 2);
        //draws the boat based on the affine transform position
        g.drawImage(playerShip, boatTrans, null);
        //updates and draws the cannons
        updateCannons(g);
        //creates an affine transform object for the sail
        AffineTransform sailTrans = new AffineTransform();
        //moves the transform to the boat x and y pos
        sailTrans.translate(xPos, yPos);
        //rotates the transform 
        sailTrans.rotate(Math.toRadians(angle));
        //scales the transform based on the screen scale
        sailTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        //translates the transform to the image centre is the x and y pos of the boat
        sailTrans.translate(-sail.getWidth(null) / 2, -sail.getHeight(null) / 2);
        //draws the sail based on the affine transform position
        g.drawImage(sail, sailTrans, null);
        //sets the paint to a new colour (grey)
        g.setPaint(new Color(100, 100, 100, 50));
        //draws the background of the health bar
        g.fillRect((int) Math.floor(xPos - 40 * DS.scale), (int) Math.floor(yPos - 70 * DS.scale), (int) Math.round(80 * DS.scale), (int) Math.round(10 * DS.scale));
        //sets the colour to a new colour (green)
        g.setPaint(new Color(13, 196, 22));
        //draws over the background of the health bar based on the health of the player
        g.fillRect((int) Math.floor(xPos - 40 * DS.scale), (int) Math.floor(yPos - 70 * DS.scale), (int) Math.round(health * 4 / 5 * DS.scale), (int) Math.round(10 * DS.scale));

    }

    /**
     * sets the player gold value
     *
     * @param val desired gold value
     */
    public void setGold(int val) {
        if (val > gold) {
            earnedGold += val-gold;
        }
        //sets the gold value toa  desired value
        gold = val;

    }

    /**
     * gets the gold value
     *
     * @return the gold value
     */
    public int getGold() {
        //returns the gold value of the player!
        return gold;
    }

    /**
     * gets the sail number
     *
     * @return the sail number of the player ship
     */
    public int getSailNumber() {
        //returns the sail number
        return sailNumber;
    }

    /**
     * sets the sail number of the ship
     *
     * @param sn the desired sail number
     */
    public void setSailNumber(int sn) {
        //changes the sail number
        this.sailNumber = sn;
        //based on the new sail number, sets the image of the sail to a new file
        if (sailNumber == 0) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (10).png");
        } else if (sailNumber == 1) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (11).png");
        } else if (sailNumber == 2) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (12).png");
        } else if (sailNumber == 3) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (13).png");
        }
    }

    /**
     * gets the sail image
     *
     * @return the image based on the current sail number
     */
    public Image getSailImage() {
        //returns the sail image
        return sail;
    }

    public int getEarnedGold() {
        return earnedGold;
    }

}
