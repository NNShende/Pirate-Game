package game;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

//Nikhil Shende, Jamie Caille, Daniel Papadopoulos
//June 12, 2017
//Ship stats is used for displaying the player's gold,
//health, shop, and cannon timer
public class ShipStats {

    private double incTime; //how much to increase the timer by for every loop
    private double curTime; //current status of the timer
    private int gold; //how much gold the player has
    private int health; //how much health the player has
    private Image bar; //image of the health bar
    private Image barBG; //image of the health bar background
    private Image shop; //image of the shop
    private Image soldOut; //image of the soldout image to display overtop

    /**
     * constructor
     *
     * @param incTime how much to increase the timer by
     * @param curTime what the current state of the timer is
     * @param gold how much gold the player has
     * @param health how much health the player has
     */
    public ShipStats(double incTime, double curTime, int gold, int health) {
        this.incTime = incTime;
        this.curTime = curTime;
        this.gold = gold;
        //load in all of the images once when the object is initialized
        bar = loadImage("/GameFiles/FireBar.png");
        barBG = loadImage("/GameFiles/FireBarBG.png");
        shop = loadImage("/GameFiles/Shop.png");
        soldOut = loadImage("/GameFiles/SoldOut.png");
    }

    /**
     * returns the incTime
     *
     * @return incTime
     */
    public double getIncTime() {
        return incTime;
    }

    /**
     * sets the incTime
     *
     * @param incTime
     */
    public void setIncTime(double incTime) {
        this.incTime = incTime;
    }

    /**
     * returns the curTime
     *
     * @return curTime
     */
    public double getCurTime() {
        return curTime;
    }

    /**
     * sets the curTime
     *
     * @param val curTime
     */
    public void setCurTime(double val) {
        curTime = val;
    }

    /**
     * update function to redraw the menu and increase the timer
     *
     * @param g
     */
    public void update(Graphics2D g) {
        if (curTime < 1) {
            curTime += incTime;
        }
        drawShipStats(g); //draw the ship stats
    }

    /**
     * draws the shop on the side of the screen
     *
     * @param g Graphcis2D object
     * @param sel selected value in the screen
     */
    public void drawShop(Graphics2D g, int sel) {
        //translate and scale the shop image to the side of the screen
        AffineTransform shopTrans = new AffineTransform();
        shopTrans.translate(DS.gameWidth + 48 * DS.scale, DS.gap + 500 * DS.scale);
        shopTrans.scale(DS.scale, DS.scale);
        g.drawImage(shop, shopTrans, null); //draw the imahe

        //outline the selected icon on the store in red
        g.setPaint(Color.red);
        g.setStroke(new BasicStroke(3));
        //draw the outline
        g.drawRect((int) Math.round(DS.gameWidth + 72 * DS.scale), (int) Math.round(DS.gap + (675 + sel * 132) * DS.scale), (int) Math.round(350 * DS.scale), (int) Math.round(90 * DS.scale));

    }

    /**
     * draws the sold out image when the specific upgrade is sold out
     *
     * @param g Graphics2D object
     * @param i thing that says which thing is sold out
     */
    public void drawSoldOut(Graphics2D g, int i) {
        //scale and transform to the correct location
        AffineTransform soldOutTrans = new AffineTransform();
        soldOutTrans.translate(DS.gameWidth + 55 * DS.scale, DS.gap + (650 + 135 * i) * DS.scale);
        soldOutTrans.scale(DS.scale, DS.scale);
        g.drawImage(soldOut, soldOutTrans, null); //draw sold out image
    }

    /**
     * method to draw the ship stats stuff
     *
     * @param g Graphics2D object
     */
    public void drawShipStats(Graphics2D g) {
        //scale and transform background bar to correct loaction
        AffineTransform barBGTrans = new AffineTransform();
        barBGTrans.translate(DS.gameWidth / 2 - 160, DS.gap + DS.gameHeight - 50);
        barBGTrans.scale(1, 0.8);
        g.drawImage(barBG, barBGTrans, null); //draw the background

        //scale and transform cannon bar image
        AffineTransform barTrans = new AffineTransform();
        barTrans.translate(DS.gameWidth / 2 - 160, DS.gap + DS.gameHeight - 50);
        barTrans.scale(curTime, 0.8);
        g.drawImage(bar, barTrans, null); //draw cannon bar image

        //set the font to display health and gold as well as cannon charge label
        //cannon charge label
        g.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        g.setPaint(Color.red);
        g.drawString("Cannon Charge", DS.gameWidth / 2 - 55, DS.gap + DS.gameHeight - 55);

        //gold
        g.setPaint(new Color(212, 175, 55));
        g.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        g.drawString("Gold: " + gold, 10, DS.gap + 70);

        //health
        g.setPaint(new Color(239, 145, 62));
        g.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        g.drawString("Health: " + health, 10, DS.gap + 30);

    }

    /**
     * returns the gold of the player
     *
     * @return gold
     */
    public int getGold() {
        return gold;
    }

    /**
     * sets the gold for the player
     *
     * @param val gold
     */
    public void setGold(int val) {
        gold = val;
    }

    /**
     * sets the health for the player
     *
     * @param val health
     */
    public void setHealth(int val) {
        health = val;
    }

    /**
     * gets the health for the player
     *
     * @return health
     */
    public int getHealth() {
        return health;
    }

    /**
     * loads the images in for use in the game
     *
     * @param src location of the file
     * @return returns the loaded image object
     */
    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {

        }
        return im;
    }

}
