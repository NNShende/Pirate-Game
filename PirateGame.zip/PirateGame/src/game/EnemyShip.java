//Daniel papadopoulos, Nikhil Shende, Jamie Caille
//June 6, 2017
//Class for enemy ships, includes random moving and automated shooting functionality
package game;
//imports the use of colour, drawing loading and moving images
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

public class EnemyShip extends Ship {
//variables for the game width and game height, image for the enemy ship and cannon timer
    private static int gameWidth = DS.gameWidth;
    private static int gameHeight = DS.gameHeight;
    private Image enemyShip;
    private int cannonTimer;
/**
 * constructor for the enemy ship
 * @param xPos the x position
 * @param yPos the y position
 * @param mS the movement speed
 * @param a the angle
 * @param h the health
 */
    public EnemyShip(double xPos, double yPos, double mS, double a, int h) {
        //super constructs a ship with the same x and y position, movement speed, angle
        // and health
        super(xPos, yPos, mS, a, h);
        //sets the enemy ship image to a loaded certain source file
        enemyShip = loadImage("/GameFiles/Ships/ship (2).png");
        //initializes the cannon timer
        cannonTimer = 0;
        //sets the front docked to be false
        frontDocked = false;
    }

    public void randomMove() {
        //if the angle is too low or too high, returns it to a value within the acceptable range
        while (angle > 360) {
            angle -= 360;
        }
        while (angle < 0) {
            angle += 360;
        }
        //fact is used as a factor, larger based on how close to the edge of the map the enemy boat is
        //and is used so that the boat doesn't tend to go off of the map
        double fact = -xPos * (xPos - DS.gameWidth) / DS.gameWidth;
        fact *= -yPos * (yPos - DS.gameHeight) / DS.gameHeight;

        double maxFact = -(DS.gameWidth / 2) * ((DS.gameWidth / 2) - DS.gameWidth) / DS.gameWidth * -(DS.gameHeight / 2) * ((DS.gameHeight / 2) - DS.gameHeight) / DS.gameHeight;
        fact = maxFact / fact;

        fact *= 2.0 / 10.0;
        fact += 1;

        //checks the quadrant, and dev is based off of how the enemy ship will move in order to stay on the screen
        double midX = DS.gameWidth / 2;
        double midY = DS.gameHeight / 2;
        double dev = Math.toDegrees(Math.abs(Math.atan((yPos - DS.gameHeight / 2) / (xPos - DS.gameWidth / 2))));
        if (yPos < midY) {
            if (xPos < midX) { //II
                dev = 90 + dev;
            } else { //I
                dev = 270 - dev;
            }
        } else {
            if (xPos < midX) { //III
                dev = 90 - dev;
            } else { //IV
                dev = 270 + dev;
            }
        }
        //if the enemy ship runs into something
        if (frontDocked) {
            //makes the desired angle the one directly across from where the boat is currently pointed
            dev = (angle - 180) - dev;
            //otherwise
        } else {
            //keeps dev in the same direction
            dev = angle - dev;
        }
        //if dev is greater than 0
        if (dev > 0) {
            //changes dev to be negative
            dev = -dev / 180 + 1;
            //otherwise
        } else {
            //keeps dev positive
            dev = dev / 180 + 1;
        }
        //if the boat isn't docked
        if (!frontDocked) {
            //increases the y value and decreases the x value
            incY();
            decX();
            //otherwise
        } else {
            //increases the x value and decreases the y value
            incX();
            decY();
        }
        //if dev is greater than 0
        if (dev > 0) {
            //if the front of the ship is docked
            if (frontDocked) {
                //rotates the ship to the left
                decR(dev * fact);
                //otherwise
            } else {
                //rotates the ship to the right
                incR(dev * fact);
            }
            //if dev is less than 0
        } else {
            //if the front of the ship is docked
            if (frontDocked) {
                //rotates the ship to the right
                incR(dev * fact);
                //otherwise
            } else {
                //rotates the ship to the left
                decR(dev * fact);
            }
        }
        //adds to the cannon timer
        cannonTimer++;
    }
    //draws the enemy ship
    public void drawEnemyShip(Graphics2D g) {
        //creates an affine transform object for the boat image
        AffineTransform boatTrans = new AffineTransform();
        //moves the transform to the boat position
        boatTrans.translate(xPos, yPos);
        //rotates the transform to the boat angle
        boatTrans.rotate(Math.toRadians(angle));
        //scales the transform upwards based on the screen size
        boatTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        //move the transform to be centred on the boat x and y position
        boatTrans.translate(-enemyShip.getWidth(null) / 2, -enemyShip.getHeight(null) / 2);
        //draws the boat according to the boattrans position
        g.drawImage(enemyShip, boatTrans, null);
        //makes the ship randomly move
        randomMove();
        //updates and draws the cannons
        updateCannons(g);
        //if the ship is ready to fire
        if (cannonTimer > 60) {
            //fires the cannons
            fireCannons();
            //resets the timer
            cannonTimer = 0;
        }
        //sets the paint to grey
        g.setPaint(new Color(100, 100, 100, 50));
        //draws the background of the health bar
        g.fillRect((int) Math.floor(xPos - 40*DS.scale), (int) Math.floor(yPos - 70*DS.scale), (int)Math.round(80*DS.scale), (int)Math.round(10*DS.scale));
        //sets the paint to red
        g.setPaint(Color.red);
        //draws over the background of the health bar based on how much health the user has
        g.fillRect((int) Math.floor(xPos - 40*DS.scale), (int) Math.floor(yPos - 70*DS.scale), (int)Math.round(health*4 / 5*DS.scale), (int)Math.round(10*DS.scale));
    }

}
