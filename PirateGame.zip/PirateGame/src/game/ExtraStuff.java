package game;
//Nikhil Shende, Jamie Caille, Daniel Papadopolous
//June 6th, 2017
//A class for an object for an extra map component
public class ExtraStuff {
    //location of extra map component
    private int mapSecX;
    private int mapSecY;
    private int squareX;
    private int squareY;
    //reference number
    private int ref;

    public ExtraStuff(int mX, int mY, int sX, int sY, int r) {
        mapSecX = mX;
        mapSecY = mY;
        squareX = sX;
        squareY = sY;
        ref = r;
    }
    
    //getters and setters
        
    public int getMapSecX() {
        return mapSecX;
    }

    public int getMapSecY() {
        return mapSecY;
    }

    public int getSquareX() {
        return squareX;
    }

    public int getSquareY() {
        return squareY;
    }

    public int getRef() {
        return ref;
    }

}
