package game;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

public class EnemyShip extends Ship {

    private static int gameWidth = DS.gameWidth;
    private static int gameHeight = DS.gameHeight;
    private double turnA;
    private double turnR;
    private Image enemyShip;
    private int cannonTimer;

    public EnemyShip() {
        super((gameWidth / 4) + (Math.random() * (gameWidth / 2)), (gameHeight / 4) + (Math.random() * (gameHeight / 2)),
                 5, 0, 75);
        turnA = Math.random() * 100;
        turnR = Math.random();
        enemyShip = loadImage("/GameFiles/Ships/ship (2).png");
        cannonTimer = 0;
    }

    public void randomMove() {
        incY();
        decX();
        if (Math.random() < turnA) {
            if (Math.random() < turnR) {
                incR();
            } else {
                decR();
            }
        }
        cannonTimer++;
    }
    
    
    public void drawEnemyShip(Graphics2D g){
        AffineTransform boatTrans = new AffineTransform();
        boatTrans.translate(xPos, yPos);
        boatTrans.rotate(Math.toRadians(angle));
        boatTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        boatTrans.translate(-enemyShip.getWidth(null) / 2, -enemyShip.getHeight(null) / 2);
        g.drawImage(enemyShip, boatTrans, null);
        randomMove();
        updateCannons(g);
        if (cannonTimer > 60){
            fireCannons();
            cannonTimer = 0;
        }
    }

}
