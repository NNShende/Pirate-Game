package game;

public class ShipStats {
    
    private int fireWaitTime;
    private int gold;
    
    public ShipStats(){
        
    }
    
}
