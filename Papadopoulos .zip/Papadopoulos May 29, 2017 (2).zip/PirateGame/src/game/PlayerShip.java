package game;

import java.awt.Graphics2D;

public class PlayerShip extends Ship {

    private int sailImageNumber;

    public PlayerShip( int sailImageNumber, double xPos, double yPos, double mS, double a, int h) {
        super(xPos, yPos, mS, a, h);
        this.sailImageNumber = sailImageNumber;
        
    }
    

}
