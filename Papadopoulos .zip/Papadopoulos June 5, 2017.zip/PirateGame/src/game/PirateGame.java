package game;

import javax.swing.JFrame;

public class PirateGame {

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        DS ds = new DS();
        frame.setSize(DS.screenWidth, DS.screenHeight);
        frame.setResizable(false);
        frame.setUndecorated(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Ye Olde Pirate Game");
        frame.add(ds);
        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        frame.setVisible(true); //must be last line for some reason

    }
    
    

}
