package game;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Fortress {

    private int health;
    private int level;
    private int numCannons;
    private Cannon[] cannons;
    private double hitBoxLeft;
    private double hitBoxRight;
    private double hitBoxUp;
    private double hitBoxDown;
    private boolean defeated;
    private int mapSecX;
    private int mapSecY;

    public Fortress(int health, int level, int numCannons, double hitBoxLeft, double hitBoxRight, double hitBoxUp, double hitBoxDown, int x, int y) {
        super();
        this.health = health;
        this.level = level;
        this.numCannons = numCannons;
        this.hitBoxLeft = hitBoxLeft;
        this.hitBoxRight = hitBoxRight;
        this.hitBoxUp = hitBoxUp;
        this.hitBoxDown = hitBoxDown;
        defeated = false;
        cannons = new Cannon[numCannons];
        mapSecX = x;
        mapSecY = y;
        init();
    }

    public Fortress() {
        this.health = 0;
        this.level = 0;
        this.numCannons = 0;
        this.cannons = new Cannon[numCannons];
        this.hitBoxLeft = 0;
        this.hitBoxRight = 0;
        this.hitBoxUp = 0;
        this.hitBoxDown = 0;
        this.defeated = false;
        this.mapSecX = 0;
        this.mapSecY = 0;
    }
    
    

    private void init() {
        this.cannons = new Cannon[numCannons];
        int side;
        for (int i = 0; i < cannons.length; i++) {
            side = (int) (Math.random() * 4);
            if (side == 0) { //left
                cannons[i] = new Cannon(hitBoxLeft * DS.tileSize + 10 * DS.scale, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp) * DS.tileSize, 0, level * 4);
            } else if (side == 1) { //right
                cannons[i] = new Cannon(hitBoxRight * DS.tileSize - 10 * DS.scale, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp) * DS.tileSize, 0, level * 4);
            } else if (side == 2) { //up
                cannons[i] = new Cannon((Math.random() * (hitBoxLeft - hitBoxRight) + hitBoxLeft) * DS.tileSize, hitBoxUp * DS.tileSize + 10 * DS.scale, 0, level * 4);
            } else if (side == 3) { //down
                cannons[i] = new Cannon((Math.random() * (hitBoxLeft - hitBoxRight) + hitBoxLeft) * DS.tileSize, hitBoxDown * DS.tileSize - 10 * DS.scale, 0, level * 4);
            }
        }

    }

    /**
     * fix THIS
     * @param g
     * @param xPos
     * @param yPos 
     */
    public void updateFortress(Graphics2D g, double xPos, double yPos) {
        for (int i = 0; i < numCannons; i++) {
            double midX = cannons[i].getXPos();
            double midY = cannons[i].getYPos();
            double dev = Math.toDegrees(Math.abs(Math.atan((yPos - DS.gameHeight / 2) / (xPos - DS.gameWidth / 2))));
            
            cannons[i].setAngle(dev);
            cannons[i].drawCannon(g);
        }
    }
    
    

    public void setMapSecX(int mapSecX) {
        this.mapSecX = mapSecX;
    }

    public void setMapSecY(int mapSecY) {
        this.mapSecY = mapSecY;
    }

    public int getMapSecX() {
        return mapSecX;
    }

    public int getMapSecY() {
        return mapSecY;
    }

    public void setHitBoxLeft(double hitBoxLeft) {
        this.hitBoxLeft = hitBoxLeft;
    }

    public void setHitBoxRight(double hitBoxRight) {
        this.hitBoxRight = hitBoxRight;
    }

    public void setHitBoxUp(double hitBoxUp) {
        this.hitBoxUp = hitBoxUp;
    }

    public void setHitBoxDown(double hitBoxDown) {
        this.hitBoxDown = hitBoxDown;
    }

    public double getHitBoxLeft() {
        return hitBoxLeft;
    }

    public double getHitBoxRight() {
        return hitBoxRight;
    }

    public double getHitBoxUp() {
        return hitBoxUp;
    }

    public double getHitBoxDown() {
        return hitBoxDown;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public void setNumCannons(int numCannons) {
        this.numCannons = numCannons;
        init();
    }
    
    


}
