package game;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.io.*;

public class ExtraMap {

    ArrayList<ExtraStuff> extraMap = new ArrayList<ExtraStuff>();

    private Image rock1;
    private Image rock2;
    private Image rock3;
    private Image grass1;
    private Image grass2;
    private Image grass3;
    private Image cFortress;
    private Image vFortress;
    private Image hFortress;
    private Image ULFortress;
    private Image DLFortress;
    private Image URFortress;
    private Image DRFortress;
    private int tileSize;
        
    public ExtraMap() {
        tileSize = DS.tileSize;
        rock1 = loadImage("/GameFiles/Tiles/tile_49.png");
        rock2 = loadImage("/GameFiles/Tiles/tile_50.png");
        rock3 = loadImage("/GameFiles/Tiles/tile_52.png");
        grass1 = loadImage("/GameFiles/Tiles/tile_70.png") ;
        grass2 = loadImage("/GameFiles/Tiles/tile_71.png");
        grass3 = loadImage("/GameFiles/Tiles/tile_72.png");
        cFortress = loadImage("/GameFiles/Tiles/tile_13.png");
        vFortress = loadImage("/GameFiles/Tiles/tile_15.png");
        hFortress = loadImage("/GameFiles/Tiles/tile_16.png");
        ULFortress = loadImage("/GameFiles/Tiles/tile_77.png");
        DLFortress = loadImage("/GameFiles/Tiles/tile_93.png");
        URFortress = loadImage("/GameFiles/Tiles/tile_78.png");
        DRFortress = loadImage("/GameFiles/Tiles/tile_94.png");
        readFile("/GameFiles/ExtraMap.txt");
    }
    
    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {

        }
        return im;
    }

    public void readFile(String filePath){
        int numLines = 0;
        try{
            InputStream in = getClass().getResourceAsStream(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            while (br.readLine() != null){
                numLines++;
            }
            br.close();
        }
        catch(IOException e){
        }
        try{
            InputStream in = getClass().getResourceAsStream(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            for(int i = 0; i < numLines/5; i++){
                int mX = Integer.parseInt(br.readLine());
                int mY = Integer.parseInt(br.readLine());
                int sX = Integer.parseInt(br.readLine());
                int sY = Integer.parseInt(br.readLine());
                int r = Integer.parseInt(br.readLine());
                extraMap.add(new ExtraStuff(mX,mY,sX,sY,r));
            }
        }
        catch(IOException e){
        }
    }
    
    public void drawExtraStuff(Graphics2D g, int mX,int mY){
        for(int i = 0; i < extraMap.size(); i++){
            if(extraMap.get(i).getMapSecX() == mX && extraMap.get(i).getMapSecY() == mY){
                if (extraMap.get(i).getRef() == 0) {
                    g.drawImage(rock1, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 1) {
                    g.drawImage(rock2, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 2) {
                    g.drawImage(rock3, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 3) {
                    g.drawImage(grass1, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 4) {
                    g.drawImage(grass2, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 5) {
                    g.drawImage(grass3, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 6) {
                    g.drawImage(cFortress, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 7) {
                    g.drawImage(vFortress, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 8) {
                    g.drawImage(hFortress, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 9) {
                    g.drawImage(ULFortress, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 10) {
                    g.drawImage(DLFortress, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 11) {
                    g.drawImage(URFortress, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                } else if (extraMap.get(i).getRef() == 12) {
                    g.drawImage(DRFortress, extraMap.get(i).getSquareX() * tileSize, extraMap.get(i).getSquareY() * tileSize + DS.gap, tileSize, tileSize, null);
                }
            }
        }
    }
}


