package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

public class EnemyShip extends Ship {

    private static int gameWidth = DS.gameWidth;
    private static int gameHeight = DS.gameHeight;
    private double turnA;
    private double turnR;
    private Image enemyShip;
    private int cannonTimer;

    public EnemyShip(double xPos, double yPos, double mS, double a, int h) {
        super(xPos, yPos, mS, a, h);
        enemyShip = loadImage("/GameFiles/Ships/ship (2).png");
        cannonTimer = 0;
        frontDocked = false;
        turnA = Math.random();
        turnR = Math.random();
    }

    public void randomMove() {

        while (angle > 360) {
            angle -= 360;
        }
        while (angle < 0) {
            angle += 360;
        }

        double fact = -xPos * (xPos - DS.gameWidth) / DS.gameWidth;
        fact *= -yPos * (yPos - DS.gameHeight) / DS.gameHeight;

        double maxFact = -(DS.gameWidth / 2) * ((DS.gameWidth / 2) - DS.gameWidth) / DS.gameWidth * -(DS.gameHeight / 2) * ((DS.gameHeight / 2) - DS.gameHeight) / DS.gameHeight;
        fact = maxFact / fact;

        fact *= 2.0 / 10.0;
        fact += 1;

        //check quadrant
        double midX = DS.gameWidth / 2;
        double midY = DS.gameHeight / 2;
        double dev = Math.toDegrees(Math.abs(Math.atan((yPos - DS.gameHeight / 2) / (xPos - DS.gameWidth / 2))));
        if (yPos < midY) {
            if (xPos < midX) { //II
                dev = 90 + dev;
            } else { //I
                dev = 270 - dev;
            }
        } else {
            if (xPos < midX) { //III
                dev = 90 - dev;
            } else { //IV
                dev = 270 + dev;
            }
        }

        if (frontDocked) {
            dev = (angle - 180) - dev;
        } else {
            dev = angle - dev;
        }
        if (dev > 0) {
            dev = -dev / 180 + 1;
        } else {
            dev = dev / 180 + 1;
        }

        if (!frontDocked) {
            incY();
            decX();
        } else {
            incX();
            decY();
        }

        if (dev > 0) {
            if (frontDocked) {
                decR(dev * fact);
            } else {
                incR(dev * fact);
            }
        } else {
            if (frontDocked) {
                incR(dev * fact);
            } else {
                decR(dev * fact);
            }
        }

        cannonTimer++;
    }

    public void drawEnemyShip(Graphics2D g) {
        AffineTransform boatTrans = new AffineTransform();
        boatTrans.translate(xPos, yPos);
        boatTrans.rotate(Math.toRadians(angle));
        boatTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        boatTrans.translate(-enemyShip.getWidth(null) / 2, -enemyShip.getHeight(null) / 2);
        g.drawImage(enemyShip, boatTrans, null);
        randomMove();
        updateCannons(g);
        if (cannonTimer > 60) {
            fireCannons();
            cannonTimer = 0;
        }
        
        g.setPaint(new Color(100, 100, 100, 50));
        g.fillRect((int) Math.floor(xPos - 40*DS.scale), (int) Math.floor(yPos - 70*DS.scale), (int)Math.round(80*DS.scale), (int)Math.round(10*DS.scale));
        
        g.setPaint(Color.red);
        g.fillRect((int) Math.floor(xPos - 40*DS.scale), (int) Math.floor(yPos - 70*DS.scale), (int)Math.round(health*4 / 5*DS.scale), (int)Math.round(10*DS.scale));
    }

}
