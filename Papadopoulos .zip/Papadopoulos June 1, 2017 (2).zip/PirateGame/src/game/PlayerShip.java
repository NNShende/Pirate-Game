package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;

public class PlayerShip extends Ship {

    private int sailNumber;
    private Image playerShip;
    private Image sail;
    private int gold;

    public PlayerShip(int sailNumber, double xPos, double yPos, double mS, double a, int h) {
        super(xPos, yPos, mS, a, h);
        this.sailNumber = sailNumber;
        playerShip = loadImage("/GameFiles/Ship_parts/hullLarge (1).png");
        sail = loadImage("/GameFiles/Ship_parts/sailLarge (10).png");
        gold = 0;
    }

    public void drawPlayerShip(Graphics2D g) {
        AffineTransform boatTrans = new AffineTransform();
        boatTrans.translate(xPos, yPos);
        boatTrans.rotate(Math.toRadians(angle));
        boatTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        boatTrans.translate(-playerShip.getWidth(null) / 2, -playerShip.getHeight(null) / 2);
        g.drawImage(playerShip, boatTrans, null);

        updateCannons(g);

        AffineTransform sailTrans = new AffineTransform();
        sailTrans.translate(xPos, yPos);
        sailTrans.rotate(Math.toRadians(angle));
        sailTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        sailTrans.translate(-sail.getWidth(null) / 2, -sail.getHeight(null) / 2);
        g.drawImage(sail, sailTrans, null);

        g.setPaint(new Color(100, 100, 100, 50));
        g.fillRect((int) Math.floor(xPos - 40*DS.scale), (int) Math.floor(yPos - 70*DS.scale), (int)Math.round(80*DS.scale), (int)Math.round(10*DS.scale));
        
        g.setPaint(new Color(13, 196, 22));
        g.fillRect((int) Math.floor(xPos - 40*DS.scale), (int) Math.floor(yPos - 70*DS.scale), (int)Math.round(health*4 / 5*DS.scale), (int)Math.round(10*DS.scale));

    }

    public void setGold(int val) {
        gold = val;
    }

    public int getGold() {
        return gold;
    }

    public int getSailNumber() {
        return sailNumber;
    }

    public void setSailNumber(int sn) {
        this.sailNumber = sn;
        if (sailNumber == 0) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (10).png");
        } else if (sailNumber == 1) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (11).png");
        } else if (sailNumber == 2) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (12).png");
        } else if (sailNumber == 3) {
            sail = loadImage("/GameFiles/Ship_parts/sailLarge (13).png");
        }
    }
    
    public Image getSailImage(){
        return sail;
    }

}
