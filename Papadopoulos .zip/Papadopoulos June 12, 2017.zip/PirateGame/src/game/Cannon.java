//Daniel Papadopoulos
//June 6, 2017
//Cannon class. Used for firing, drawing cannons and drawing cannonballs
package game;
//importsthe use of drawing moving and loading images
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

public class Cannon {
    //variables for the x and y position, angle, speed, cannonball array, cannonball array index
    //and cannon image
    private double xPos;
    private double yPos;
    private double angle;
    private double speed;
    private Cannonball[] balls;
    private int count;
    private Image cannon;
    //variable for the maximum amount of cannonballs allowed
    public static int maxBalls = 10;
/**
 * constructor for the cannon
 * @param xPos the x position
 * @param yPos the y position
 * @param angle the angle
 * @param speed the speed
 */
    public Cannon(double xPos, double yPos, double angle, double speed) {
        //sets the x position
        this.xPos = xPos;
        //sets the y position
        this.yPos = yPos;
        //sets the angle
        this.angle = angle;
        //sets the speed
        this.speed = speed;
        //creates a new cannonball array of length 10, puts it on the balls
        balls = new Cannonball[maxBalls];
        //initializes count to 0
        count = 0;
        //loads the cannonball image
        cannon = loadImage("/GameFiles/Ship_parts/cannon.png");
    }
/**
 * sets the speed of a cannon
 * @param speed the desired speed
 */
    public void setSpeed(double speed) {
        //sets the speed
        this.speed = speed;
    }
    /**
     * gets a cannonball at a certain index of the cannonballs array
     * @param i the index of the desired cannonball
     * @return the cannonball at that index
     */
    public Cannonball getCannonball(int i){
        //returns the cannonball at a certain index
        return balls[i];
    }
    /**
     * deletes a cannonball at a certain index
     * @param i the index of the desired cannonball
     */
    public void deleteCannonball(int i){
        //sets the cannonball at the certain index to not be there anymore
        balls[i] = null;
    }
    /**
     * draws the cannon
     * @param g the Graphics2D object used to draw
     */
    public void drawCannon(Graphics2D g) {
        //creates an affine transform object for the cannon image
        AffineTransform cannonTrans = new AffineTransform();
        //moves the transform to the cannon's position
        cannonTrans.translate(xPos, yPos);
        //rotates the transform to the cannon's angle
        cannonTrans.rotate(Math.toRadians(angle));
        //scales the transform upwards based on the screen size
        cannonTrans.scale(1.5 * DS.scale, 1.5 * DS.scale);
        //moves the transform to be centred on the cannon x and y position
        cannonTrans.translate(-cannon.getWidth(null) / 2, -cannon.getHeight(null) / 2);
        //draws the cannon based on the transform
        g.drawImage(cannon, cannonTrans, null);
        //draws the cannonballs of the cannon
        drawBalls(g);

    }
/**
 * loads an image
 * @param src the source file of the image
 * @return the image
 */
    public Image loadImage(String src) {
        //creates a variable for the image
        Image im = null;
        //try to do this
        try {
            //loads the image from the source file
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
            //if something goes wrong, do nothing 
        } catch (Exception e) {

        }
        //returns the image
        return im;
    }
/**
 * draws the cannonballs
 * @param g the Graphics2D object to draw cannonballs with
 */
    public void drawBalls(Graphics2D g) {
        //goes through the cannonballs array
        for (int i = 0; i < balls.length; i++) {
            //if there is a cannonball at the current index
            if (balls[i] != null) {
                //moves and draws the cannonball
                balls[i].move();
                balls[i].drawCannonball(g);

            }
        }
    }
/**
 * clears the cannonball array when a ship dies
 */
    public void clearBalls() {
        //goes through the cannonballs array
        for (int i = 0; i < balls.length; i++) {
            //sets each index to null
            balls[i] = null;
        }
    }
/**
 * gets the x position of a cannon
 * @return the x position
 */
    public double getXPos() {
        //returns the x position
        return xPos;
    }
/**
 * gets the y position of the cannon
 * @return the y position
 */
    public double getYPos() {
        //returns the y position
        return yPos;
    }
/**
 * gets the angle of the cannon
 * @return the angle
 */
    public double getAngle() {
        //returns the angle
        return angle;
    }
/**
 * fires the cannonballs from a cannon
 */
    public void fireCannonball() {
        //the cannonball at the count index is initialized
        balls[count] = new Cannonball(xPos, yPos, angle + 270, speed);
        //increases count by one
        count++;
        //if count is greater than the cannonball array length
        if (count >= balls.length) {
            //resets count to 0
            count = 0;
        }
        //this one is different from others because there is a maximum amount of cannonballs
        //and if it is reached starts changing cannonballs starting at the beginning of the
        //array

    }
/**
 * sets the x position of the cannon
 * @param x the x position
 */
    public void setXPos(double x) {
        //sets the x position
        xPos = x;
    }
/**
 * sets the y position of the cannon
 * @param y the y position
 */
    public void setYPos(double y) {
        //sets the y position
        yPos = y;
    }
/**
 * sets the angle of the cannon
 * @param a the angle
 */
    public void setAngle(double a) {
        //sets the angle
        angle = a;
    }

}
