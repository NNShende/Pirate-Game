package game;

import static game.DS.gameWidth;
import static game.DS.gap;
import static game.DS.scale;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

public class Fortress {

    private int health;
    private final int MAX_HEALTH;
    private int numCannons;
    private Cannon[] cannons;
    private double hitBoxLeft;
    private double hitBoxRight;
    private double hitBoxUp;
    private double hitBoxDown;
    private boolean defeated;
    private int mapSecX;
    private int mapSecY;
    private Image defeatedIm;

    public Fortress(int health, int numCannons, double hitBoxLeft, double hitBoxRight, double hitBoxUp, double hitBoxDown, int x, int y) {
        super();
        this.MAX_HEALTH = health;
        this.health = health;
        this.numCannons = numCannons;
        this.hitBoxLeft = hitBoxLeft;
        this.hitBoxRight = hitBoxRight;
        this.hitBoxUp = hitBoxUp;
        this.hitBoxDown = hitBoxDown;
        cannons = new Cannon[numCannons];
        defeated = false;
        mapSecX = x;
        mapSecY = y;
        defeatedIm = loadImage("/GameFiles/Defeated.png");
        init();
    }

    public Fortress() {
        this.health = 0;
        this.MAX_HEALTH = 0;
        this.numCannons = 0;
        this.cannons = new Cannon[numCannons];
        this.hitBoxLeft = 0;
        this.hitBoxRight = 0;
        this.hitBoxUp = 0;
        this.hitBoxDown = 0;
        this.defeated = false;
        this.mapSecX = 0;
        this.mapSecY = 0;
        defeatedIm = loadImage("/GameFiles/Defeated.png");
    }

    public void drawHealth(Graphics2D g) {
        double xPos = (hitBoxRight - hitBoxLeft) / 2 + hitBoxLeft;
        double yPos = (hitBoxDown - hitBoxUp) / 2 + hitBoxUp;
        if (!defeated) {

            g.setPaint(new Color(100, 100, 100, 50));
            g.fillRect((int) Math.round(-150 * DS.scale + xPos), (int) Math.round(-20 * DS.scale + yPos), (int) Math.round(300 * DS.scale), (int) Math.round(40 * DS.scale));

            g.setPaint(Color.red);
            g.fillRect((int) Math.round(-150 * DS.scale + xPos), (int) Math.round(-20 * DS.scale + yPos), (int) Math.round(300 * DS.scale * (health * 1000 / MAX_HEALTH) / 1000), (int) Math.round(40 * DS.scale));
        } else {
            AffineTransform defeatedTrans = new AffineTransform();
            defeatedTrans.translate(xPos , yPos);
            defeatedTrans.scale(DS.scale*0.2, DS.scale*0.2);
            defeatedTrans.translate(-defeatedIm.getWidth(null)/2, -defeatedIm.getHeight(null)/2);
            g.drawImage(defeatedIm, defeatedTrans, null);
        }
    }

    private void init() {
        this.cannons = new Cannon[numCannons];
        int side;
        for (int i = 0; i < cannons.length; i++) {
            side = (int) (Math.random() * 4);
            if (side == 0) { //left
                cannons[i] = new Cannon(hitBoxLeft * DS.tileSize + 10 * DS.scale, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp) * DS.tileSize, 0, 12);
            } else if (side == 1) { //right
                cannons[i] = new Cannon(hitBoxRight * DS.tileSize - 10 * DS.scale, (Math.random() * (hitBoxDown - hitBoxUp) + hitBoxUp) * DS.tileSize, 0, 12);
            } else if (side == 2) { //up
                cannons[i] = new Cannon((Math.random() * (hitBoxLeft - hitBoxRight) + hitBoxLeft) * DS.tileSize, hitBoxUp * DS.tileSize + 10 * DS.scale, 0, 12);
            } else if (side == 3) { //down
                cannons[i] = new Cannon((Math.random() * (hitBoxLeft - hitBoxRight) + hitBoxLeft) * DS.tileSize, hitBoxDown * DS.tileSize - 10 * DS.scale, 0, 12);
            }
        }

    }

    public void updateFortress(Graphics2D g, double xPos, double yPos) {
        for (int i = 0; i < numCannons; i++) {
            double midX = cannons[i].getXPos();
            double midY = cannons[i].getYPos();
            double dev = Math.toDegrees(Math.abs(Math.atan((yPos - DS.gameHeight / 2) / (xPos - DS.gameWidth / 2))));

            cannons[i].setAngle(dev);
            cannons[i].drawCannon(g);
        }

        drawHealth(g);
    }

    public void setMapSecX(int mapSecX) {
        this.mapSecX = mapSecX;
    }

    public void setMapSecY(int mapSecY) {
        this.mapSecY = mapSecY;
    }

    public int getMapSecX() {
        return mapSecX;
    }

    public int getMapSecY() {
        return mapSecY;
    }

    public void setHitBoxLeft(double hitBoxLeft) {
        this.hitBoxLeft = hitBoxLeft;
    }

    public void setHitBoxRight(double hitBoxRight) {
        this.hitBoxRight = hitBoxRight;
    }

    public void setHitBoxUp(double hitBoxUp) {
        this.hitBoxUp = hitBoxUp;
    }

    public void setHitBoxDown(double hitBoxDown) {
        this.hitBoxDown = hitBoxDown;
    }

    public double getHitBoxLeft() {
        return hitBoxLeft;
    }

    public double getHitBoxRight() {
        return hitBoxRight;
    }

    public double getHitBoxUp() {
        return hitBoxUp;
    }

    public double getHitBoxDown() {
        return hitBoxDown;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public void setNumCannons(int numCannons) {
        this.numCannons = numCannons;
        init();
    }

    public int getHealth() {
        return health;
    }

    public void setDefeated(boolean a) {
        defeated = a;
    }

    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {
 
        }
        return im;
    }
    
}
