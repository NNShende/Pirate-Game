package game;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

public class Cannon {

    private double xPos;
    private double yPos;
    private double angle;
    private double speed;
    private Cannonball[] balls;
    private int count;
    private Image cannon;
    
    public static int maxBalls = 10;

    public Cannon(double xPos, double yPos, double angle, double speed) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.angle = angle;
        this.speed = speed;
        balls = new Cannonball[maxBalls];
        count = 0;
        cannon = loadImage("/GameFiles/Ship_parts/cannon.png");
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }
    
    
    
    public Cannonball getCannonball(int i){
        
        return balls[i];
    }
    
    public void deleteCannonball(int i){
        balls[i] = null;
    }
    public void drawCannon(Graphics2D g) {

        AffineTransform cannonTrans = new AffineTransform();
        cannonTrans.translate(xPos, yPos);
        cannonTrans.rotate(Math.toRadians(angle));
        cannonTrans.scale(1.5 * DS.scale, 1.5 * DS.scale);
        cannonTrans.translate(-cannon.getWidth(null) / 2, -cannon.getHeight(null) / 2);
        g.drawImage(cannon, cannonTrans, null);
        drawBalls(g);

    }

    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {

        }
        return im;
    }

    public void drawBalls(Graphics2D g) {
        for (int i = 0; i < balls.length; i++) {
            if (balls[i] != null) {
                balls[i].move();
                balls[i].drawCannonball(g);

            }
        }
    }

    public void clearBalls() {
        for (int i = 0; i < balls.length; i++) {
            balls[i] = null;
        }
    }

    public double getXPos() {
        return xPos;
    }

    public double getYPos() {
        return yPos;
    }

    public double getAngle() {
        return angle;
    }

    public void fireCannonball() {
        balls[count] = new Cannonball(xPos, yPos, angle + 90, speed);
        count++;
        if (count >= balls.length) {
            count = 0;
        }

    }

    public void setXPos(double x) {
        xPos = x;
    }

    public void setYPos(double y) {
        yPos = y;
    }

    public void setAngle(double a) {
        angle = a;
    }

}
