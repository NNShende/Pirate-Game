package game;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.AffineTransform;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.swing.JPanel;
import javax.swing.Timer;

public class DS extends JPanel implements ActionListener, KeyListener {

    public static int screenWidth;
    public static int screenHeight;
    public static int gameWidth;
    public static int gameHeight;
    public static int tileSize;
    public static double scale;
    public static int gap;

    private Timer timer;
    private final int FPS = 60;
    private int delay = 1000 / FPS;

    private boolean right = false;
    private boolean left = false;
    private boolean up = false;
    private boolean down = false;
    private boolean space = false;
    private boolean escape = false;
    private boolean enter = false;
    private boolean inShop = false;

    private int timePirateNoise = 0;
    private String line[] = new String[5];
    private int displace = 0;

    private int menuSelect = 1;
    private int optionSelect = 1;
    private boolean onLeft = true;
    private String[] menuPlay = {"Play!", "Start"};
    private String[] menuSettings = {"Settings!", "Ship Sail Colour"};
    private String[] menuCredits = {"Credits!", "This game was", "made by Daniel P,", "Nikhil S and ", "Jamie C."};
    private String[] menuExit = {"Close game?", "Exit", "Continue"};
    private String[][] menuSelections = {menuPlay, menuSettings, menuCredits, menuExit};
    private int[] timesToUpgrade = {4, 4, 1, 4};
    private double spawnChance = 0.5;

    public boolean gamePlay = false;
    public boolean gameStarted = false;

    private Map map;
    private ExtraMap extraMap;
    private Ship playerShip;
    private ShipStats ss;
    private Ship enemyShip;
    private Fortress[] fortresses;

    public static void getBestSize() {
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();

        screenWidth = screenSize.width;
        screenHeight = screenSize.height;

        int sizeFactorX = screenWidth / 19;
        int sizeFactorY = screenHeight / 10;

        if (sizeFactorX > sizeFactorY) {
            tileSize = sizeFactorY;
        } else {
            tileSize = sizeFactorX;
        }
        gameWidth = tileSize * 14;
        gameHeight = tileSize * 10;
        gap = (screenHeight - gameHeight) / 2;
        scale = tileSize / 128.0;
    }

    public DS() {
        init();
        addKeyListener(this);
        setFocusable(true);
        timer = new Timer(delay, this);
        timer.start();
    }

    public void init() {
        getBestSize();
        map = new Map();
        extraMap = new ExtraMap();
        playerShip = new PlayerShip(0, gameWidth / 5, gameHeight / 3, 10, 270, 100, 100);
        map.setMapSecX(2);
        map.setMapSecY(2);

        ss = new ShipStats(0.02, 0, ((PlayerShip) playerShip).getGold());

        fortresses = loadFortresses();
    }

    public void paintComponent(Graphics g_) {
        Graphics2D g = (Graphics2D) g_;

        setFocusable(true);
        requestFocusInWindow();

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (!gamePlay) {
            g.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
            map.drawMap(g);
            Image titlePic = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/GameFiles/Title.png"));
            AffineTransform titleTrans = new AffineTransform();
            titleTrans.translate(DS.gameWidth * 0.075, DS.gap * 1.5);
            titleTrans.scale(DS.scale * 0.5, DS.scale * 0.5);
            g.drawImage(titlePic, titleTrans, null);
            g.fillRect(gameWidth / 8, DS.gap + (5 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            g.fillRect(gameWidth / 8, DS.gap + (8 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            g.fillRect(gameWidth / 8, DS.gap + (11 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            g.fillRect(gameWidth / 8, DS.gap + (14 * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);
            g.setColor(Color.WHITE);
            g.drawString("Start!", gameWidth / 2 - Math.round(90 * scale), DS.gap + (6 * gameHeight / 17) + Math.round(scale * 20));
            g.drawString("Settings", gameWidth / 2 - Math.round(110 * scale), DS.gap + (9 * gameHeight / 17) + Math.round(scale * 20));
            g.drawString("Credits", gameWidth / 2 - Math.round(102 * scale), DS.gap + (12 * gameHeight / 17) + Math.round(scale * 20));
            g.drawString("Close", gameWidth / 2 - Math.round(73 * scale), DS.gap + (15 * gameHeight / 17) + Math.round(scale * 20));
            g.setColor(Color.RED);
            g.setStroke(new BasicStroke(10));
            if (menuSelect == 5) {
                menuSelect = 1;
            } else if (menuSelect == 0) {
                menuSelect = 4;
            }
            if (menuSelections[menuSelect - 1].length != 1) {
                if (optionSelect == menuSelections[menuSelect - 1].length) {
                    optionSelect = 1;
                } else if (optionSelect == 0) {
                    optionSelect = menuSelections[menuSelect - 1].length - 1;
                }

            }

            if (!onLeft && menuSelections[menuSelect - 1].length != 1) {
                g.drawRect(gameWidth + ((screenWidth - gameWidth) / 30), DS.gap + (gameHeight / 10) * (optionSelect + 1) + ((2 / 3 * DS.gap) + (gameHeight / 10)) / 2, ((screenWidth - gameWidth) * 9 / 10), (2 / 3 * DS.gap) + (gameHeight / 10));
            }

            g.drawRect(gameWidth / 8, DS.gap + ((2 + (3 * menuSelect)) * gameHeight / 17), gameWidth * 3 / 4, gameHeight * 2 / 17);

            for (int i = 0; i < menuSelections[menuSelect - 1].length - 1; i++) {
                g.drawString(menuSelections[menuSelect - 1][i + 1], gameWidth + ((screenWidth - gameWidth) / 10), DS.gap + (gameHeight / 10) * (i + 3) + Math.round(scale * 15));
            }

            if (menuSelect == 2) {
                Image sail = ((PlayerShip) playerShip).getSailImage();
                AffineTransform sailTrans = new AffineTransform();
                sailTrans.translate((screenWidth - gameWidth) / 2 + gameWidth, screenHeight / 2);
                sailTrans.scale(DS.scale * 5, DS.scale * 5);
                sailTrans.translate(-sail.getWidth(null) / 2, 0);
                g.drawImage(sail, sailTrans, null);
            }
            if (menuSelect == 3) {
                displace++;
                for (int i = 0; i < line.length; i++) {
                    //

                    //
                    //
                    //
                    //
                    g.drawString(line[i], gameWidth + ((screenWidth - gameWidth) / 10), DS.gap + (i + gameHeight / 10) - (displace / 900));

                }
            }
            g.setColor(Color.BLACK);
            g.fillRect(gameWidth, DS.gap, (screenWidth - gameWidth), gameHeight / 5);
            g.setColor(Color.RED);
            g.drawString(menuSelections[menuSelect - 1][0], gameWidth + ((screenWidth - gameWidth) / 10), DS.gap + (gameHeight / 10));
        }
        if (gamePlay) {
            map.drawMap(g);
            extraMap.drawExtraStuff(g, map.getMapSecX(), map.getMapSecY());
            double xRan = (Math.random() * gameWidth);
            double yRan = (Math.random() * gameHeight);
            double spawnChance = 0.5;
            if (map.getMapSecY() < map.getMapSecYSize() - 1 && playerShip.getY() > gameHeight) {
                map.setMapSecY(map.getMapSecY() + 1);
                playerShip.setY(gap);
                playerShip.clearBalls();
                enemyShip = null;
                spawnEnemyShip();
            }
            if (map.getMapSecY() > 0 && playerShip.getY() < 0) {
                map.setMapSecY(map.getMapSecY() - 1);
                playerShip.setY(gameHeight + gap);
                playerShip.clearBalls();
                enemyShip = null;
                spawnEnemyShip();
            }
            if (map.getMapSecX() < map.getMapSecXSize() - 1 && playerShip.getX() > gameWidth) {
                map.setMapSecX(map.getMapSecX() + 1);
                playerShip.setX(0);
                playerShip.clearBalls();
                enemyShip = null;
                spawnEnemyShip();
            }
            if (map.getMapSecX() > 0 && playerShip.getX() < 0) {
                map.setMapSecX(map.getMapSecX() - 1);
                playerShip.setX(gameWidth);
                playerShip.clearBalls();
                enemyShip = null;
                spawnEnemyShip();
            }
            if (enemyShip != null) {
                ((EnemyShip) enemyShip).drawEnemyShip(g);
            }

            ss.setHealth(playerShip.getHealth());
            ss.setGold(((PlayerShip) playerShip).getGold());
            ((PlayerShip) playerShip).drawPlayerShip(g);
            ss.update(g);

            int x = map.getMapSecX();
            int y = map.getMapSecY();

            for (int i = 0; i < fortresses.length; i++) {
                if (fortresses[i].getMapSecX() == x && fortresses[i].getMapSecY() == y) {
                    fortresses[i].updateFortress(g, playerShip.getX(), playerShip.getY());
                    double x1 = fortresses[i].getHitBoxLeft();
                    double x2 = fortresses[i].getHitBoxRight();
                    double y1 = fortresses[i].getHitBoxUp();
                    double y2 = fortresses[i].getHitBoxDown();

                    Cannon c[] = playerShip.getCannonArray();
                    for (int j = 0; j < c.length; j++) {
                        for (int k = 0; k < Cannon.maxBalls; k++) {
                            Cannon cc = playerShip.getCannon(j);
                            if (cc != null) {
                                Cannonball cb = cc.getCannonball(k);
                                if (cb != null) {
                                    if (cb.getXPos() > x1 && cb.getXPos() < x2 && cb.getYPos() > y1 && cb.getYPos() < y2) {
                                        playerShip.deleteCannonball(j, k);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            timePirateNoise++;
            if (timePirateNoise >= 600) {
                timePirateNoise = 0;
                double noise = Math.random();
                if (noise < 0.25) {
                    playerShip.so.playPirate1();
                } else if (noise < 0.5) {
                    playerShip.so.playPirate2();
                } else if (noise < 0.75) {
                    playerShip.so.playPirate3();
                } else {
                    playerShip.so.playPirate4();
                }
            }

            map.drawSidebar(g);
            if (map.getMapSecX() == 2 && map.getMapSecY() == 2) {
                map.drawShopText(g);
                if ((playerShip.getFrontDocked() || playerShip.getBackDocked()) && ((int) Math.floor(playerShip.getX() / tileSize) == 6) && ((int) Math.floor(playerShip.getY() / tileSize) == 5)) {

                    if (!inShop) {
                        menuSelect = 0;
                        inShop = true;
                    }
                    ss.drawShop(g, menuSelect);
                    for (int i = 0; i < 4; i++) {
                        if (timesToUpgrade[i] == 0) {
                            ss.drawSoldOut(g, i);
                        }
                    }

                } else {
                    menuSelect = 0;
                    inShop = false;
                }
            }

            g.setPaint(Color.black);
            g.fillRect(0, 0, screenWidth, gap);
            g.fillRect(0, screenHeight - gap, screenWidth, gap);
        }

    }

    public void upgradeShip(int sel) {
        if (timesToUpgrade[sel] > 0) {
            if (sel == 0) {
                if (((PlayerShip) playerShip).getGold() >= 10) {
                    playerShip.setMoveSpeed(playerShip.getMoveSpeed() + 2);
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 10);
                    timesToUpgrade[sel]--;
                }
            } else if (sel == 1) {
                if (((PlayerShip) playerShip).getGold() >= 20) {
                    playerShip.setDamage(playerShip.getDamage() + 2);
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 20);
                    timesToUpgrade[sel]--;
                }
            } else if (sel == 2) {
                if (((PlayerShip) playerShip).getGold() >= 50) {
                    playerShip.addCannons();
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 50);
                    timesToUpgrade[sel]--;
                }
            } else if (sel == 3) {
                if (((PlayerShip) playerShip).getGold() >= 15) {
                    ss.setIncTime(ss.getIncTime() + 0.02);
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() - 15);
                    timesToUpgrade[sel]--;
                }
            }

        }
    }

    public void activateMenuAction() {
        if (menuSelect == 1) {
            gamePlay = true;
            gameStarted = true;
        } else if (menuSelect == 2) {
            int col = ((PlayerShip) playerShip).getSailNumber();
            if (col < 3) {
                ((PlayerShip) playerShip).setSailNumber(col + 1);
            } else {
                ((PlayerShip) playerShip).setSailNumber(0);
            }
        } else if (menuSelect == 4) {
            if (optionSelect == 2) {
                if (gameStarted) {
                    gamePlay = true;
                } else {
                    menuSelect = 1;
                    onLeft = true;
                }
            } else {
                System.exit(0);
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        setFocusable(true);
        requestFocusInWindow();
        repaint();
        if (!playerShip.getFrontDocked() && !playerShip.getBackDocked()) {
            if (right && (up || down)) {
                playerShip.incR(1);
            }
            if (left && (up || down)) {
                playerShip.decR(1);
            }
        }
        if (up && !playerShip.getFrontDocked()) {
            playerShip.decX();
            playerShip.incY();
        }
        if (down && !playerShip.getBackDocked()) {
            playerShip.incX();
            playerShip.decY();
        }

        if (enemyShip != null) {
            enemyShip = playerShip.updateHealth(enemyShip);
            playerShip = enemyShip.updateHealth(playerShip);
        }

        try {
            if (up && map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) != 0 && playerShip.getBackDocked() == false) {
                playerShip.setFrontDocked(true);
            } else if (map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) == 0) {
                playerShip.setFrontDocked(false);
            }
            if (down && map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) != 0 && playerShip.getFrontDocked() == false) {
                playerShip.setBackDocked(true);
            } else if (map.getTile((int) Math.floor(playerShip.getX() / tileSize), (int) Math.floor(playerShip.getY() / tileSize)) == 0) {
                playerShip.setBackDocked(false);
            }
            if (enemyShip != null) {
                if (!enemyShip.getFrontDocked() && map.getTile((int) Math.floor(enemyShip.getX() / tileSize), (int) Math.floor(enemyShip.getY() / tileSize)) != 0) {
                    enemyShip.setFrontDocked(true);
                } else if (enemyShip.getFrontDocked() && map.getTile((int) Math.floor(enemyShip.getX() / tileSize), (int) Math.floor(enemyShip.getY() / tileSize)) != 0) {
                    enemyShip.setFrontDocked(false);
                }

                if (enemyShip.getHealth() <= 0) {
                    enemyShip = null;
                    ((PlayerShip) playerShip).setGold(((PlayerShip) playerShip).getGold() + 5);
                    if (playerShip.getHealth() > 70) {
                        playerShip.setHealth(100);
                    } else {
                        playerShip.setHealth(playerShip.getHealth() + 30);
                    }

                }
            }

        } catch (Exception ex) {
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (!gamePlay) {
            int key = e.getKeyCode();
            if (onLeft) {
                if (key == KeyEvent.VK_DOWN) {
                    menuSelect++;
                    if (menuSelect == 3) {
                        displace = 0;
                    }
                }
                if (key == KeyEvent.VK_UP) {
                    menuSelect--;
                    if (menuSelect == 3) {
                        displace = 0;
                    }
                }
                if (key == KeyEvent.VK_RIGHT && menuSelect != 3) {
                    onLeft = false;
                }
            } else {
                if (key == KeyEvent.VK_LEFT) {
                    onLeft = true;
                    optionSelect = 1;
                } else if (key == KeyEvent.VK_UP) {
                    optionSelect--;
                } else if (key == KeyEvent.VK_DOWN) {
                    optionSelect++;
                } else if (key == KeyEvent.VK_ENTER) {
                    activateMenuAction();
                }
            }

        } else {
            int key = e.getKeyCode();

            if (key == KeyEvent.VK_A) {
                left = true;
            }

            if (key == KeyEvent.VK_D) {
                right = true;
            }

            if (key == KeyEvent.VK_W) {
                up = true;
            }

            if (key == KeyEvent.VK_S) {
                down = true;
            }

            if (key == KeyEvent.VK_SPACE) {
                space = true;
            }

            if (inShop) {
                if (key == KeyEvent.VK_DOWN) {
                    menuSelect++;
                } else if (key == KeyEvent.VK_UP) {
                    menuSelect--;
                }
                if (menuSelect > 3) {
                    menuSelect = 0;
                } else if (menuSelect < 0) {
                    menuSelect = 3;
                }
                if (key == KeyEvent.VK_ENTER) {
                    enter = true;
                }
            }

            if (key == KeyEvent.VK_ESCAPE) {
                escape = true;
            }
        }

    }

    @Override
    public void keyReleased(KeyEvent e) {

        if (gamePlay) {
            int key = e.getKeyCode();

            if (key == KeyEvent.VK_A) {
                left = false;
            }

            if (key == KeyEvent.VK_D) {
                right = false;
            }

            if (key == KeyEvent.VK_W) {
                up = false;
            }

            if (key == KeyEvent.VK_S) {
                down = false;
            }

            if (key == KeyEvent.VK_SPACE && space) {
                space = false;
                if (ss.getCurTime() >= 1) {
                    playerShip.fireCannons();
                    ss.setCurTime(0);
                    playerShip.so.playCannon();
                }
            }

            if (key == KeyEvent.VK_ESCAPE) {
                escape = false;
                gamePlay = false;
                menuSelect = 4;
                onLeft = false;
                optionSelect = 1;
            }

            if (inShop) {
                if (key == KeyEvent.VK_ENTER) {
                    upgradeShip(menuSelect);
                }
            }
        }
    }

    public void spawnEnemyShip() {
        if (!(map.getMapSecX() == 2 && map.getMapSecY() == 2)) {
            double xRan = Math.random() * gameWidth;
            double yRan = Math.random() * gameHeight;
            if (Math.random() < spawnChance) {
                while (map.getTile((int) Math.floor(xRan / tileSize), (int) Math.floor(yRan / tileSize)) != 0) {
                    xRan = (Math.random() * gameWidth);
                    yRan = (Math.random() * gameHeight);
                }
                enemyShip = new EnemyShip(xRan, yRan + gap, (int) (Math.random() * 5) + 4, Math.random() * 360, 100);

            }
        }

    }

    public Fortress[] loadFortresses() {
        int numForts = 0;
        try {
            InputStream in = getClass().getResourceAsStream("/GameFiles/FortressHitboxData.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            numForts = Integer.parseInt(br.readLine());
            br.close();
        } catch (IOException e) {
        }
        Fortress[] f = new Fortress[numForts];
        try {
            InputStream in = getClass().getResourceAsStream("/GameFiles/FortressHitboxData.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            br.readLine();
            for (int i = 0; i < numForts; i++) {
                f[i] = new Fortress();
                br.readLine();
                String line1[] = br.readLine().split(" ");
                f[i].setMapSecX(Integer.parseInt(line1[0]));
                f[i].setMapSecY(Integer.parseInt(line1[1]));
                String line2[] = br.readLine().split(" ");
                f[i].setHitBoxLeft(tileSize * Integer.parseInt(line2[0]));
                f[i].setHitBoxUp(tileSize * Integer.parseInt(line2[1]) + gap);
                String line3[] = br.readLine().split(" ");
                f[i].setHitBoxRight(tileSize * (Integer.parseInt(line3[0]) + 1));
                f[i].setHitBoxDown(tileSize * (Integer.parseInt(line3[1]) + 1) + gap);
                f[i].setNumCannons(Integer.parseInt(br.readLine()));
                f[i].setHealth(Integer.parseInt(br.readLine()));
            }
            br.close();
        } catch (IOException e) {
        }
        return f;
    }

}
