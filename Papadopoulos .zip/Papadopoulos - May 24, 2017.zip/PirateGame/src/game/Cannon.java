package game;

public class Cannon {

    private double xPos;
    private double yPos;
    private double angle;
    private double speed;
    private Cannonball[] balls;
    private int count;

    public Cannon(double xPos, double yPos, double angle, double speed) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.angle = angle;
        this.speed = speed;
        balls = new Cannonball[10];
        count = 0;
    }

    public double getXPos() {
        return xPos;
    }

    public double getYPos() {
        return yPos;
    }

    public double getAngle() {
        return angle;
    }

    public void fireCannonball(Cannonball c) {
        balls[2 * count] = new Cannonball(xPos, yPos, angle, speed);
        balls[2 * count + 1] = new Cannonball(xPos, yPos, angle + 180, speed);
        count++;
        if (count > 4) {
            count = 0;
        }

    }
    
    public void setXPos(double x){
        xPos = x;
    }
    
    public void setYPos(double y){
        yPos = y;
    }
    
    public void setAngle(double a){
        angle = a;
    }

}
