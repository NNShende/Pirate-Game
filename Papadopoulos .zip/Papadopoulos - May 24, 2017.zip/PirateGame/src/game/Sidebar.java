package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

public class Sidebar {

    private int xPos;
    private int yPos;
    private double scale;

    public Sidebar(int xPos, int yPos, double scale) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.scale = scale;
        
    }

    public void drawSidebar(Graphics2D g) {
        
        
        
    }

    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {
        }
        return im;
    }

}
