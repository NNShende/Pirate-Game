package game;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.AffineTransform;

abstract public class Ship {

    protected double xPos;
    protected double yPos;
    protected double angle;
    protected double moveSpeed;
    protected boolean frontDocked;
    protected boolean backDocked;
    protected int health;
    protected Cannon[] cans;

    public Ship(double xPos, double yPos, double mS, double a, int h) {//, Cannon[] c) {
        this.xPos = xPos;
        this.yPos = yPos;
        angle = a;
        moveSpeed = mS*DS.scale;
        System.out.println(DS.scale);
        frontDocked = false;
        backDocked = false;
        cans = new Cannon[2];
        cans[0] = new Cannon(xPos, yPos, angle + 90, moveSpeed * 1.5);
        cans[1] = new Cannon(xPos, yPos, angle + 270, moveSpeed * 1.5);

    }

    public void drawBoat(Graphics2D g) {
        Image boat = loadImage("/GameFiles/Ship_parts/hullLarge (1).png");

        AffineTransform boatTrans = new AffineTransform();
        boatTrans.translate(xPos, yPos);
        boatTrans.rotate(Math.toRadians(angle));
        boatTrans.scale(DS.scale * 1.5, DS.scale * 1.5);
        boatTrans.translate(-boat.getWidth(null) / 2, -boat.getHeight(null) / 2);
        g.drawImage(boat, boatTrans, null);

        updateCannons(g);
    }

    public void updateCannons(Graphics2D g) {
        drawCannons(g);
    }

    public void drawCannons(Graphics2D g) {
        Image cannon = loadImage("/GameFiles/Ship_parts/cannon.png");

        for (int i = 0; i < cans.length; i++) {
            cans[i].setXPos(xPos);
            cans[i].setYPos(yPos);
            AffineTransform cannonTrans = new AffineTransform();
            if (i % 2 == 0) {
                cans[i].setAngle(angle);
                cannonTrans.translate(cans[i].getXPos() + 18 * Math.cos(Math.toRadians(angle)), cans[i].getYPos() + 18 * Math.sin(Math.toRadians(angle)));
            } else {
                cans[i].setAngle(angle + 180);
                cannonTrans.translate(cans[i].getXPos() - 18 * Math.cos(Math.toRadians(angle)), cans[i].getYPos() - 18 * Math.sin(Math.toRadians(angle)));
            }
            cannonTrans.rotate(Math.toRadians(cans[i].getAngle()));
            cannonTrans.scale(1.5 * DS.scale, 1.5 * DS.scale);
            cannonTrans.translate(-cannon.getWidth(null) / 2, -cannon.getHeight(null) / 2);
            g.drawImage(cannon, cannonTrans, null);
        }
    }

    public Image loadImage(String src) {
        Image im = null;
        try {
            im = Toolkit.getDefaultToolkit().getImage(getClass().getResource(src));
        } catch (Exception e) {

        }
        return im;
    }

    public void incX() {
        xPos += moveSpeed * Math.sin(Math.toRadians(angle));
    }

    public void decX() {
        xPos -= moveSpeed * Math.sin(Math.toRadians(angle));
    }

    public void incY() {
        yPos += moveSpeed * Math.cos(Math.toRadians(angle));
    }

    public void decY() {
        yPos -= moveSpeed * Math.cos(Math.toRadians(angle));
    }

    public void incR() {
        angle += moveSpeed * DS.scale;
    }

    public void decR() {
        angle -= moveSpeed * DS.scale;
    }

    public double getX() {
        return xPos;
    }

    public double getY() {
        return yPos - DS.gap;
    }

    public void setX(double val) {
        xPos = val;
    }

    public void setY(double val) {
        yPos = val;
    }

    public void setFrontDocked(boolean val) {
        frontDocked = val;
    }

    public void setBackDocked(boolean val) {
        backDocked = val;
    }

    public boolean getFrontDocked() {
        return frontDocked;
    }

    public boolean getBackDocked() {
        return backDocked;
    }

}
